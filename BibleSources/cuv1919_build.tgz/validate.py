import re,json,glob,collections,difflib
BOOKS="GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV".split()
ref={}
for f in glob.glob('/tmp/claude-0/zh/s/*.usfm'):
    s=open(f,encoding='utf-8').read()
    bk=re.search(r'\\id (\S+)',s).group(1)
    if bk not in BOOKS: continue
    b=BOOKS.index(bk)+1
    s=re.sub(r'\\f .*?\\f\*','',s,flags=re.S); s=re.sub(r'\\x .*?\\x\*','',s,flags=re.S)
    ch=0
    for tok in re.split(r'(\\c \d+|\\v \d+(?:-\d+)?)',s):
        m=re.match(r'\\c (\d+)',tok)
        if m: ch=int(m.group(1)); cur=None; continue
        m=re.match(r'\\v (\d+)',tok)
        if m: cur=(b,ch,int(m.group(1))); ref[cur]=''; continue
        if ch and cur: ref[cur]+=re.sub(r'\\[a-z0-9]+\*?','',tok)
ours={tuple(map(int,k.split('|'))):t for k,t in json.load(open('/tmp/claude-0/zh/work/cuvS.json')).items()}
def norm(t,o):
    if o: t=re.sub(r'〔[^〕]*〕','',t); t=t.replace('上帝','神')
    return ''.join(ch for ch in t if '\u4e00'<=ch<='\u9fff' or '\u3400'<=ch<='\u4dbf')
subs=collections.Counter(); ex=collections.defaultdict(list); same=0; n=0
for k,t in ours.items():
    if k not in ref: continue
    a=norm(t,True); b=norm(ref[k],False); n+=1
    if a==b: same+=1; continue
    for op,i1,i2,j1,j2 in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
        if op=='replace' and i2-i1==j2-j1 and i2-i1<=2:
            for x,y in zip(a[i1:i2],b[j1:j2]): subs[(x,y)]+=1; 
            if len(ex[(a[i1:i2],b[j1:j2])])<3: ex[(a[i1:i2],b[j1:j2])].append(k)
print('compared',n,'identical',same)
for (x,y),c in subs.most_common(80): print(x,'→',y,c, ex.get((x,y),[])[:2])
json.dump({'%s>%s'%k:v for k,v in subs.items()},open('/tmp/claude-0/zh/work/subs.json','w'),ensure_ascii=False)
