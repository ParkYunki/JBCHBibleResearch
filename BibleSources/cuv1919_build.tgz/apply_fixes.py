"""Apply QC fixes to the CUV1919 bundle.

cuvT.json --fixes_T--> cuvT_fixed.json --opencc t2s--> --fixes_S--> cuvS_fixed.json
then re-run the ours->reference substitution count (same method as validate.py) on the result.
"""
import json, re, collections, difflib, sys
import opencc

W = '/tmp/claude-0/zh/work/'


def load(p):
    return json.load(open(W + p, encoding='utf-8'))


def apply_T(T, fixes):
    T = dict(T)
    for f in fixes:
        t = T[f['ref']]
        n = t.count(f['old'])
        if n != 1:
            sys.exit(f"fixes_T: {f['ref']} old {f['old']!r} occurs {n} times")
        T[f['ref']] = t.replace(f['old'], f['new'], 1)
    return T


def apply_global(s, rules):
    for r in rules:
        pat = re.compile(r['pattern'])
        spans = [(m.start(), m.end()) for e in r.get('exceptions', [])
                 for m in re.finditer(re.escape(e), s)]
        def sub(m):
            if any(a <= m.start() and m.end() <= b for a, b in spans):
                return m.group(0)
            return r['repl']
        s = pat.sub(sub, s)
    return s


def build_S(T, fs):
    cc = opencc.OpenCC('t2s')
    S = {k: apply_global(cc.convert(t), fs['global']) for k, t in T.items()}
    for f in fs['per_verse']:
        s = S[f['ref']]
        n = s.count(f['old'])
        if n != 1:
            sys.exit(f"fixes_S: {f['ref']} old {f['old']!r} occurs {n} times")
        S[f['ref']] = s.replace(f['old'], f['new'], 1)
    return S


def substitution_report(S, top=60):
    # reference = eBible cu89s USFM, parsed exactly as validate.py does
    src = open(W + 'validate.py', encoding='utf-8').read().split('ours=')[0]
    env = {}
    exec(src, env)
    ref = env['ref']
    def norm(t, o):
        if o:
            t = re.sub(r'〔[^〕]*〕', '', t); t = t.replace('上帝', '神')
        return ''.join(ch for ch in t if '一' <= ch <= '鿿' or '㐀' <= ch <= '䶿')
    subs = collections.Counter(); ex = collections.defaultdict(list); same = n = 0
    for k, t in S.items():
        k = tuple(map(int, k.split('|')))
        if k not in ref: continue
        a = norm(t, True); b = norm(ref[k], False); n += 1
        if a == b: same += 1; continue
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
            if op == 'replace' and i2 - i1 == j2 - j1 and i2 - i1 <= 2:
                for x, y in zip(a[i1:i2], b[j1:j2]):
                    subs[(x, y)] += 1
                    if len(ex[(x, y)]) < 2: ex[(x, y)].append('%d:%d:%d' % k)
    print('compared', n, 'identical', same, 'distinct pairs', len(subs), 'total', sum(subs.values()))
    for (x, y), c in subs.most_common(top):
        print(f'{x}→{y} {c} {ex[(x, y)]}')
    json.dump({'%s>%s' % k: v for k, v in subs.items()},
              open(W + 'subs_fixed.json', 'w', encoding='utf-8'), ensure_ascii=False)


if __name__ == '__main__':
    T = apply_T(load('cuvT.json'), load('fixes_T.json'))
    S = build_S(T, load('fixes_S.json'))
    assert set(T) == set(S)
    json.dump(T, open(W + 'cuvT_fixed.json', 'w', encoding='utf-8'), ensure_ascii=False)
    json.dump(S, open(W + 'cuvS_fixed.json', 'w', encoding='utf-8'), ensure_ascii=False)
    print('verses', len(T))
    substitution_report(S, int(sys.argv[1]) if len(sys.argv) > 1 else 60)
