import re, json, difflib
W = '/tmp/claude-0/zh/work/'
def K(k): return tuple(map(int, k.split('|')))
def isc(ch): return '一' <= ch <= '鿿' or '㐀' <= ch <= '䶿' or '\U00020000' <= ch <= '\U0003ffff' or '豈'<=ch<='﫿'
def norm_o(t):
    t = re.sub(r'〔[^〕]*〕', '', t); return ''.join(c for c in t if isc(c))
def norm_r(t):
    t = re.sub(r'（[^）]*）', '', t); t = re.sub(r'\([^)]*\)', '', t); return ''.join(c for c in t if isc(c))
def units(O, R):
    """yield (label, [our keys], ours_norm, ref_norm, ours_raw, ref_raw)"""
    out = []
    for rk, rt in R.items():
        b, c, v = rk.split('|')
        if '-' in v: a, z = map(int, v.split('-'))
        else: a = z = int(v)
        ks = [f'{b}|{c}|{i}' for i in range(a, z + 1) if f'{b}|{c}|{i}' in O]
        ot = ''.join(O[k] for k in ks)
        out.append((rk, ks, norm_o(ot), norm_r(rt), ot, rt))
    return out

def norm_r2(t):
    t = re.sub(r'（\s*細拉\s*）', '', t); return ''.join(c for c in t if isc(c))
MERGE = {(43, 7): (43, 8), (66, 12): (66, 13)}   # cross-chapter verse moves: compare these chapters together
def chapters(O, R):
    """return {chapkey: (ours_str, ours_posmap[list of verse keys], ref_str, ref_posmap)}"""
    def grp(b, c): return MERGE.get((b, c), (b, c))
    oc = {}; rc = {}
    for k in sorted(O, key=K):
        b, c, v = K(k); g = grp(b, c)
        s = norm_o(O[k]); x = oc.setdefault(g, ['', []]); x[0] += s; x[1] += [k] * len(s)
    for k in sorted(R, key=lambda k: (K(k.split('-')[0]) if '-' not in k else tuple(map(int, (k.split('|')[0], k.split('|')[1], k.split('|')[2].split('-')[0]))))):
        b, c = map(int, k.split('|')[:2]); g = grp(b, c)
        s = norm_r2(R[k]); x = rc.setdefault(g, ['', []]); x[0] += s; x[1] += [k] * len(s)
    return {g: (oc.get(g, ['', []])[0], oc.get(g, ['', []])[1], rc.get(g, ['', []])[0], rc.get(g, ['', []])[1]) for g in set(oc) | set(rc)}

def diffs(O, R):
    """list of dicts: g, op, o, r, okey, rkey, octx, rctx, i1"""
    out = []
    for g, (a, am, b, bm) in sorted(chapters(O, R).items()):
        sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
        for op, i1, i2, j1, j2 in sm.get_opcodes():
            if op == 'equal': continue
            ok = am[i1] if i1 < len(am) else (am[-1] if am else None)
            rk = bm[j1] if j1 < len(bm) else (bm[-1] if bm else None)
            out.append(dict(g=g, op=op, o=a[i1:i2], r=b[j1:j2], okey=ok, rkey=rk, i1=i1, i2=i2,
                            octx=a[max(0, i1 - 6):i1] + '[' + a[i1:i2] + ']' + a[i2:i2 + 6],
                            rctx=b[max(0, j1 - 6):j1] + '[' + b[j1:j2] + ']' + b[j2:j2 + 6]))
    return out
