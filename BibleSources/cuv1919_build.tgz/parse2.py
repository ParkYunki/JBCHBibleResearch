import re,json,sys,collections
sys.path.insert(0,'/tmp/claude-0/zh/work')
from decode_cuv import decode
rows={}; orphans=[]; dups=[]
for b in range(1,67):
    s,_=decode(open(f'/tmp/claude-0/zh/cuv/{b:02d}.html','rb').read())
    s=s.replace('\r','')
    parts=re.split(r'<BR>',s,flags=re.I)
    last=None
    for p in parts:
        t0=re.sub(r'<[^>]+>','',p)
        m=re.match(r'\s*([^\s\d:]{1,3}?)(\d+)(?::(\d+))?\s+(.*)',t0,re.S)
        if m and (m.group(3) or b in (31,57,63,64,65)):
            if m.group(3): ch,v=int(m.group(2)),int(m.group(3))
            else: ch,v=1,int(m.group(2))
            t=re.sub(r'\s*\n\s*','',m.group(4)).strip()
            k=(b,ch,v)
            if k in rows: dups.append((k,rows[k][:30],t[:30])); rows[k]+=t
            else: rows[k]=t
            last=k
        else:
            t=re.sub(r'\s*\n\s*','',t0).strip()
            if t: orphans.append((b,last,t[:60]))
print('verses',len(rows)); print('dups',dups); print('orphans',len(orphans)); print(orphans[:20])
json.dump({f'{b}|{c}|{v}':t for (b,c,v),t in rows.items()},open('/tmp/claude-0/zh/work/cuv_raw.json','w'),ensure_ascii=False)
