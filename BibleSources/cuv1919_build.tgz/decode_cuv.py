import re,codecs
def handler(e):
    bad=e.object[e.start:e.start+2]
    if bad==b'\xa3\xf0': return ('—',e.start+2)
    raise e
codecs.register_error('cuvfix',handler)
def valid(x): return 0x40<=x<=0x7E or 0xA1<=x<=0xFE
def repair(raw):
    out=bytearray(); i=0; n=len(raw); log=[]
    while i<n:
        b=raw[i]
        if 0x81<=b<=0xFE and i+1<n:
            nx=raw[i+1]
            if valid(nx): out+=raw[i:i+2]; i+=2; continue
            if raw[i+1:i+5].upper()==b'<BR>':
                # converter turned the byte pair a1 bb into <BR>; restore it
                log.append(('BR',i)); out.append(b); out+=b'\xa1\xbb'[0:1]; # a1 is trail of b
                out+=b'\xbb'; i+=5; 
                # now 'bb' is a lead whose trail is the next byte
                continue
            if nx in (0x0a,0x0d):
                k=i+1
                while k<n and raw[k] in (0x0a,0x0d): k+=1
                if k<n and valid(raw[k]): log.append(('NL',i)); out+=bytes([b,raw[k]]); i=k+1; continue
        out.append(b); i+=1
    return bytes(out),log
def decode(raw):
    r,log=repair(raw)
    return r.decode('big5hkscs','cuvfix'),log
