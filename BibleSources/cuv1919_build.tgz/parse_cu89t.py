"""Parse eBible cmn-cu89t USFM -> {'b|c|v' or 'b|c|v1-v2': text}  (reference only)."""
import re, glob, json
BOOKS = ("GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM "
         "EZK DAN HOS JOL AMO OBA JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP COL "
         "1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV").split()
DROP_LINE = re.compile(r'^\\(id|h|toc\d|mt\d|ms\d|s\d|r|d|sp)\b')

def parse(d='/tmp/claude-0/zh/t/'):
    ref = {}
    for f in sorted(glob.glob(d + '*.usfm')):
        s = open(f, encoding='utf-8').read()
        bk = re.search(r'\\id (\S+)', s).group(1)
        if bk not in BOOKS: continue
        b = BOOKS.index(bk) + 1
        s = re.sub(r'\\f .*?\\f\*', '', s, flags=re.S); s = re.sub(r'\\x .*?\\x\*', '', s, flags=re.S)
        s = '\n'.join(l for l in s.split('\n') if not DROP_LINE.match(l.strip()))
        ch = 0; cur = None
        for tok in re.split(r'(\\c \d+|\\v \d+(?:-\d+)?)', s):
            m = re.match(r'\\c (\d+)', tok)
            if m: ch = int(m.group(1)); cur = None; continue
            m = re.match(r'\\v (\d+)(?:-(\d+))?', tok)
            if m:
                cur = f'{b}|{ch}|{m.group(1)}' + (f'-{m.group(2)}' if m.group(2) else ''); ref[cur] = ''; continue
            if ch and cur: ref[cur] += re.sub(r'\\[a-z0-9]+\*?', '', tok)
    return {k: re.sub(r'\s+', '', v) for k, v in ref.items()}

if __name__ == '__main__':
    R = parse(); print(len(R), sum('-' in k for k in R))
    json.dump(R, open('/tmp/claude-0/zh/work/cu89t.json', 'w', encoding='utf-8'), ensure_ascii=False)
    print(R['42|1|1-2'])
