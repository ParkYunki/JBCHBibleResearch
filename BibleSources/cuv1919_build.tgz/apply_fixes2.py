"""Apply the second QC pass to the CUV1919 bundle (no sqlite is written here).

cuvT_fixed.json --fixes_T2--> + JDG 20:28 「見上節」 --> cuvT_fixed2.json
                 --opencc t2s--> fixes_S.json (global rules, then per-verse) --> 𨱔→鐏, JDG 20:28 「见上节」 --> cuvS_fixed2.json
Then re-runs the character comparison against eBible cmn-cu89t (reference only) and prints a summary.
"""
import json, sys, collections

W = '/tmp/claude-0/zh/work/'
sys.path.insert(0, W)
from apply_fixes import load, apply_T, build_S  # same semantics as pass 1 (old must occur exactly once)

JDG_20_28 = '7|20|28'


def main():
    T = apply_T(load('cuvT_fixed.json'), load('fixes_T2.json'))
    if JDG_20_28 not in T:
        sys.exit('JDG 20:28 missing')
    T[JDG_20_28] = '見上節'
    S = build_S(T, load('fixes_S.json'))
    S = {k: s.replace('𨱔', '鐏') for k, s in S.items()}
    S[JDG_20_28] = '见上节'
    assert set(T) == set(S)
    assert not any('𨱔' in s for s in S.values())
    json.dump(T, open(W + 'cuvT_fixed2.json', 'w', encoding='utf-8'), ensure_ascii=False)
    json.dump(S, open(W + 'cuvS_fixed2.json', 'w', encoding='utf-8'), ensure_ascii=False)
    print('verses', len(T), 'fixes_T2', len(load('fixes_T2.json')))

    # verification against cu89t (reference only)
    from cmp_lib import diffs
    R = load('cu89t.json')
    before = diffs(load('cuvT_fixed.json'), R)
    after = diffs(T, R)
    print('diff ops vs cu89t: before', len(before), 'after', len(after))
    c = collections.Counter(d['op'] for d in after)
    print('after by op', dict(c))


if __name__ == '__main__':
    main()
