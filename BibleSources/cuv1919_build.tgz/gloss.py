import re, glob, sys
BASE = '/home/claude/repo/Tools/LiteralGen/packets/vi-id-fil/'
BK = ("GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB PSA PRO ECC SNG ISA JER LAM EZK DAN HOS JOL AMO OBA "
      "JON MIC NAM HAB ZEP HAG ZEC MAL MAT MRK LUK JHN ACT ROM 1CO 2CO GAL EPH PHP COL 1TH 2TH 1TI 2TI TIT PHM HEB JAS 1PE 2PE 1JN 2JN 3JN JUD REV").split()
def gloss(b, c, v, words=False):
    code = BK[b - 1]
    for f in sorted(glob.glob(f'{BASE}{b:02d}_{code}/{code}_{c:03d}*.txt')):
        s = open(f, encoding='utf-8').read()
        m = re.search(rf'^#{v}\n(.*?)(?=^#\d|\Z)', s, re.S | re.M)
        if not m: continue
        for line in m.group(1).splitlines():
            if line.startswith('O '):
                pairs = re.findall(r'(\S+?(?: [פס])?)=(.*?)(?= \S+(?: [פס])?=|$)', line[2:].strip())
                return ' '.join(f'{h}={g}' if words else g for h, g in pairs)
    return None
if __name__ == '__main__':
    for a in sys.argv[1:]:
        b, c, v = map(int, a.split('|')); print(a, gloss(b, c, v, True))
