import json,sqlite3,opencc,re,sys,os
raw={tuple(map(int,k.split('|'))):t for k,t in json.load(open('/tmp/claude-0/zh/work/cuv_raw.json')).items()}
# duplicates in source (GEN 32:25, 35:14) were the same line twice -> parse2 concatenated; undo
for k in [(1,32,25),(1,35,14)]:
    t=raw[k]; h=len(t)//2
    assert t[:h]==t[h:], k
    raw[k]=t[:h]
moves=[]
# EXO 16:35 trailing note = KJV 16:36
t=raw[(2,16,35)]; m=re.search(r'(〔俄梅珥乃伊法十分之一〕)$',t); assert m
raw[(2,16,35)]=t[:m.start()]; raw[(2,16,36)]=m.group(1); moves.append('出16:35 끝 〔俄梅珥乃伊法十分之一〕 → 16:36')
# 1CH 21:31 -> 22:1, 22:1-18 -> 22:2-19
for v in range(18,0,-1): raw[(13,22,v+1)]=raw.pop((13,22,v))
raw[(13,22,1)]=raw.pop((13,21,31)); moves.append('代上21:31 → 22:1, 22:1–18 → 22:2–19')
# JHN 8:1 split -> 7:53
t=raw[(43,8,1)]; a,b=t.split('．',1); raw[(43,7,53)]=a+'．'; raw[(43,8,1)]=b; moves.append('約8:1 앞부분 「於是各人都回家去了．」 → 7:53')
# 3JN 15 -> append to 14
raw[(64,1,14)]=raw[(64,1,14)]+raw.pop((64,1,15)); moves.append('約參15 → 14 뒤에 붙임')
ref=set(sqlite3.connect('/mnt/user-data/uploads/JBCHBibleResearch/JBCHBibleResearch/Resources/Bible_THKJV.sqlite').execute('select book_id,chapter,verse from BibleVerses'))
assert set(raw)<=ref, sorted(set(raw)-ref)
print('missing vs KJV',sorted(ref-set(raw)))
sys.path.insert(0,'/home/claude'); 
def write(rows,out):
    rows=sorted(rows,key=lambda r:r[:3])
    if os.path.exists(out): os.remove(out)
    db=sqlite3.connect(out)
    db.execute('CREATE TABLE "BibleVerses" ("uid" INTEGER, "book_id" INTEGER NOT NULL, "chapter" INTEGER NOT NULL, "verse" INTEGER NOT NULL, "content" TEXT NOT NULL, "paragraph" INTEGER, PRIMARY KEY("uid")) WITHOUT ROWID')
    db.executemany('INSERT INTO BibleVerses VALUES (?,?,?,?,?,?)',[(i+1,)+tuple(r) for i,r in enumerate(rows)])
    db.execute('CREATE UNIQUE INDEX "uidx_bible_verse" ON "BibleVerses" ("book_id","chapter","verse")')
    db.commit(); db.execute('VACUUM'); db.close()
cc=opencc.OpenCC('t2s')
T=[(b,c,v,t,None) for (b,c,v),t in raw.items()]
S=[(b,c,v,cc.convert(t),None) for (b,c,v),t in raw.items()]
os.makedirs('/tmp/claude-0/zh/out',exist_ok=True)
write(T,'/tmp/claude-0/zh/out/Bible_CUV1919.sqlite'); write(S,'/tmp/claude-0/zh/out/Bible_CUV1919S.sqlite')
json.dump({f'{b}|{c}|{v}':t for b,c,v,t,_ in S},open('/tmp/claude-0/zh/work/cuvS.json','w'),ensure_ascii=False)
print(len(T),len(S)); print('\n'.join(moves))
print(S[0][3], [r for r in S if r[:3]==(43,3,16)][0][3])
