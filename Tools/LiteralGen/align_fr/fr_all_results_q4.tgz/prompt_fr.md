너는 성경 원어 단어와 프랑스어 직역 문장을 짝짓는다. 아래 규칙을 정확히 지켜라.

# 입력
절마다 다음 블록이 온다.
```
## 책:장:절
FR: 프랑스어 직역 문장
1 원어 = 영어 문맥 번역 (사전 뜻) ⟶ 힌트
2 ...
```
번호는 그 절 안의 단어 번호다. `⟶` 뒤의 힌트는 같은 원어 단어가 다른 언어 직역에서 짝지어진 말이다(`IT:` 이탈리아어, `ES:` 스페인어). 힌트는 하나일 수도, ` | `로 나뉜 둘일 수도, 아예 없을 수도 있다(`⟶`가 없는 줄). `—`는 그 언어에 짝이 없다는 뜻이다.
- 힌트는 프랑스어에서 같은 뜻의 말을 찾는 참고 자료일 뿐이다. 틀릴 수 있고, 여러 낱말을 한 덩어리로 묶었을 수 있다. **최종 판단은 원어 단어의 뜻과 프랑스어 문장으로 한다.** 힌트가 없거나 `—`여도 프랑스어에 대응하는 말이 있으면 짝짓고, 힌트가 있어도 프랑스어에 대응하는 말이 없으면 짝짓지 않는다.
- `⟶ (직역에 없음: 짝 짓지 말 것)`으로 표시된 단어는 프랑스어 직역이 옮기지 않은 사본 단어다. 이 번호는 절대 출력하지 않는다(프랑스어 문장에 비슷한 말이 있어도 쓰지 않는다).

# 출력 (엄격)
- 절마다 정확히 한 줄: `책:장:절` + 공백 1칸 + 표시한 문장.
- 프랑스어 문장을 한 글자도 바꾸지 말고 그대로 옮기되, 원어 단어에 대응하는 부분만 `{구간|번호}`로 감싼다.
- `{`, `|`, `}`와 번호를 지우면 프랑스어 문장과 글자·악센트·아포스트로피(`’`와 `'`를 서로 바꾸지 않는다)·하이픈·띄어쓰기(` : `, ` ; `, ` ? `, `« `처럼 부호 앞뒤의 공백 포함)·문장부호·쉼표·어순까지 완전히 같아야 한다.
- 입력의 모든 절을 입력 순서대로, 절마다 한 번만 출력한다. 제목, 설명, 정정, 빈 줄, 코드블록(```)을 쓰지 않는다.

# 짝짓기 규칙
1. 구간은 낱말(띄어쓰기 단위) 하나, 또는 붙어 있는 여러 낱말 전체다. 낱말 가운데를 쪼개지 않는다. 관사가 붙은 전치사(`au`, `aux`, `du`, `des`)는 쪼개지 않는다.
2. 아포스트로피로 이어진 말(`l’homme`, `d’Israël`, `qu’il`, `n’est`, `s’en`, `c’est`, `jusqu’à`)은 아포스트로피에서 두 낱말로 본다. 앞 조각과 뒤 낱말에 각각 대응하는 원어 단어가 있으면 따로 감싼다: `{l|8}'{Agneau|9}`. 앞 조각에 대응하는 원어 단어가 없으면 뒤 낱말만 감싼다: `l’{homme|5}`. 원어 한 단어가 둘을 함께 뜻하면 통째로 감싼다: `{d'un linge|16}`. **구간은 아포스트로피로 시작하거나 끝나지 않는다**(`{d’|3}`, `{qu’|5}`처럼 쓰지 않는다. 앞 조각만 감쌀 때는 `{d|3}’`처럼 아포스트로피를 구간 밖에 둔다).
3. 하이픈:
   - 동사 뒤에 하이픈으로 붙은 대명사가 **원어에 따로 있는 단어**이면 하이픈에서 나누어 따로 감싼다: `{Déliez|22}-{le|23}`, `{laissez|25}-{le|26}`.
   - 대명사가 원어에 따로 없고 동사 어미에만 있으면(`dit-il`, `Lève-toi`, `es-tu`) 통째로 감싼다: `{dit-il|6}`.
   - 발음용 `-t-`(`a-t-il`)는 따로 감싸지 않는다. 대명사를 나눌 때는 `{a|3}-t-{il|2}`처럼 둔다.
   - 하이픈으로 이어진 이름·합성어(`Très-Haut`, `Obed-Édom`, `peut-être`, `c’est-à-dire`)는 한 낱말로 본다.
   - 하이픈 자체는 구간의 처음이나 끝에 두지 않는다.
4. 단어 앞뒤의 문장부호 `. , ; : ? ! " ' ’ « » “ ” ‘ ( ) [ ] —`와 그 앞뒤 공백은 구간 밖에 둔다.
5. 한 단어 번호는 한 번만 쓴다. 뜻이 두 곳에 흩어져 있으면 뜻의 중심 하나만 고른다.
   - 부정 `ne … pas/point/jamais/rien/personne/plus`가 떨어져 있으면 뒤쪽 말(`pas`, `jamais` 등)을 감싸고 `ne`/`n`은 감싸지 않는다: `il n’{alla|5} {pas|4}`.
   - `ne`만 있으면 `ne`를 감싼다.
6. 구간은 잘게 나눈다. 원어 단어마다 그 뜻을 맡은 프랑스어 낱말이 따로 있으면 단어마다 따로 감싼다: `{la|4} {Parole|5}`, `{leur|19} {dit|18}`. 힌트가 여러 원어 단어에 같은 덩어리(`il suo volto`, `su rostro`)를 보여 주더라도 프랑스어에서는 나눈다.
7. 프랑스어 한 낱말이 여러 원어 단어의 뜻을 함께 담고 있어 나눌 수 없을 때만 여러 번호를 함께 쓴다. 번호를 쉼표로 오름차순: `{au|1,2}`(전치사 + 관사가 원어에 따로 있을 때).
8. 원어 한 단어가 붙어 있는 여러 프랑스어 낱말로 옮겨졌으면 함께 감싼다: `{Et il arriva|1}`, `{de son accouchement|3}`, `{était enveloppé|17}`.
9. 주어 대명사: 원어 동사 하나에 주어가 들어 있고 프랑스어가 바로 붙은 대명사와 동사로 옮겼으면(`il dit`, `ils allèrent`) 함께 감싼다: `{il dit|6}`. 원어에 주어 대명사가 따로 있으면(αὐτός, הוּא 등) 따로 감싼다. 대명사와 동사 사이에 다른 말이 끼어 있으면 동사만 감싼다.
10. 관사:
    - 원어에 관사가 따로 있고 프랑스어 관사(`le/la/les/l’`)가 그것을 옮겼으면 관사를 따로 감싼다.
    - 원어에 관사가 없는데 프랑스어 문법 때문에 들어간 관사나 부분관사(`des`, `du`, `de la`)는 감싸지 않는다.
    - 원어 관사가 프랑스어에 없거나 소유형용사(`son`, `sa`, `leur`)로 바뀌었으면 관사 번호를 쓰지 않는다.
    - 히브리어 목적격 표지(<obj.>)는 쓰지 않는다.
11. 소유·소속의 `de`(`d’`, `du`, `des`, `de la`)는 **뜻풀이에 `of`가 들어 있는 원어 단어 쪽**에 붙인다.
    - 히브리어 연계형: 앞 명사의 뜻풀이가 `[the] sons of`, `[the] king of`, `word of`처럼 `of`로 끝나면 `de`는 앞 명사와 함께 감싸고, 뒤 명사는 `de` 없이 감싼다: `{les fils de|1} {Cusch|2}`, `{roi de|3} {Salem|4}`, `{roi d|7}’{Assyrie|8}`.
    - 헬라어 속격: 속격 명사의 뜻풀이가 `of God`, `of him`처럼 `of`로 시작하면 `de`는 그 속격 명사와 함께 감싼다: `{le|10} {Fils|11} {de Dieu|13}`, `{du Dieu|5}`.
    - 어느 쪽 뜻풀이에도 `of`가 없으면 `de`는 감싸지 않는다.
12. 대응이 없는 원어 단어는 쓰지 않는다. 대응하는 원어가 없는 프랑스어 낱말은 감싸지 않는다. 원어에 동사가 없는데 프랑스어가 보충한 `est`·`était`·`étaient`·`il y a`·`c’est` 같은 말(뜻풀이에 `[were]`처럼 대괄호로 표시됨)은 감싸지 않는다.
13. 같은 낱말이 여러 번 나오면 원어 순서와 문맥에 맞는 자리를 감싼다.
14. 프랑스어 시제·어순이 원어 번역과 달라도 같은 뜻이면 짝짓는다.

# 예
입력:
```
## 43:1:1
FR: Au commencement était la Parole, et la Parole était auprès de Dieu, et la Parole était Dieu.
1 Ἐν = In [the] (in/on/among) ⟶ IT: Nel | ES: En el principio
2 ἀρχῇ = beginning ⟶ IT: principio | ES: En el principio
3 ἦν = was (to be) ⟶ IT: era | ES: era
4 ὁ = the (the/this/who) ⟶ IT: la | ES: el Verbo
5 λόγος = Word, (word) ⟶ IT: Parola | ES: el Verbo
6 καὶ = and ⟶ IT: e | ES: y
7 ὁ = the (the/this/who) ⟶ IT: la
8 λόγος = Word ⟶ IT: Parola
9 ἦν = was (to be) ⟶ IT: era | ES: era
10 πρὸς = with (to/with) ⟶ IT: presso | ES: con
11 τὸν = <the> (the/this/who) ⟶ IT: — | ES: —
12 θεόν = God, (God) ⟶ IT: Dio | ES: Dios
13 καὶ = and ⟶ IT: e | ES: y
14 θεὸς = God ⟶ IT: Dio | ES: Dios
15 ἦν = was (to be) ⟶ IT: era | ES: era
16 ὁ = the (the/this/who) ⟶ IT: la
17 λόγος = Word. (word) ⟶ IT: Parola

## 1:38:27
FR: Et il arriva au temps de son accouchement, et voici, des jumeaux étaient dans son ventre.
1 וַיְהִי = and it was (to be) ⟶ IT: E avvenne | ES: Y sucedió
2 בְּעֵת = at [the] time (time) ⟶ IT: al tempo | ES: al tiempo
3 לִדְתָּהּ = gave birth she (to beget) ⟶ IT: del suo partorire | ES: de su parto
4 וְהִנֵּה = and there! (behold) ⟶ IT: ed ecco | ES: y he aquí
5 תְאוֹמִים = twins (twin) ⟶ IT: gemelli | ES: había gemelos
6 בְּבִטְנָהּ = [were] in womb her (belly) ⟶ IT: nel suo ventre | ES: en su vientre

## 43:1:36
FR: Et ayant fixé les yeux sur Jésus qui marchait, il dit : Voici l'Agneau de Dieu.
1 καὶ = And ⟶ IT: E | ES: Y
2 ἐμβλέψας = having looked at (to look into/upon) ⟶ IT: fissato lo sguardo su | ES: mirando
3 τῷ = <the> (the/this/who)
4 Ἰησοῦ = Jesus (Jesus/Joshua) ⟶ IT: Gesù
5 περιπατοῦντι = walking (to walk) ⟶ IT: che passava | ES: que andaba
6 λέγει· = he says; (to speak) ⟶ IT: dice | ES: dice
7 ἴδε = Behold (look!) ⟶ IT: Ecco | ES: He aquí
8 ὁ = the (the/this/who) ⟶ IT: l
9 ἀμνὸς = Lamb ⟶ IT: Agnello
10 τοῦ = <the> (the/this/who)
11 θεοῦ = of God! (God) ⟶ IT: di Dio

## 43:11:44
FR: Le mort sortit, les pieds et les mains liés de bandes, et son visage était enveloppé d'un linge. Jésus leur dit : Déliez-le, et laissez-le aller.
1 καὶ = and ⟶ (직역에 없음: 짝 짓지 말 것)
2 ἐξῆλθεν = Came forth (to go out) ⟶ IT: Uscì | ES: Salió
3 ὁ = the [one] (the/this/who) ⟶ IT: il | ES: el que había muerto
4 τεθνηκὼς = having died (to die/be dead) ⟶ IT: morto | ES: el que había muerto
5 δεδεμένος = bound (to bind) ⟶ IT: legato | ES: atados
6 τοὺς = the (the/this/who) ⟶ IT: — | ES: los pies
7 πόδας = feet (foot) ⟶ IT: piedi | ES: los pies
8 καὶ = and ⟶ IT: e | ES: y
9 τὰς = the (the/this/who) ⟶ IT: — | ES: las manos
10 χεῖρας = hands (hand) ⟶ IT: mani | ES: las manos
11 κειρίαις = with linen strips, (graveclothes) ⟶ IT: con fasce | ES: con vendas
12 καὶ = and ⟶ IT: e | ES: y
13 ἡ = the (the/this/who) ⟶ IT: il | ES: su rostro
14 ὄψις = face ⟶ IT: volto | ES: su rostro
15 αὐτοῦ = of him (he/she/it/self) ⟶ IT: suo | ES: su rostro
16 σουδαρίῳ = in a headcloth (handkerchief) ⟶ IT: in un sudario | ES: en un sudario
17 περιεδέδετο = had bound about. (to wrap around) ⟶ IT: era avvolto | ES: estaba envuelto
18 λέγει = Says (to speak) ⟶ IT: Dice | ES: Les dice
19 αὐτοῖς = to them (he/she/it/self) ⟶ IT: loro | ES: Les dice
20 ὁ = <the> (the/this/who) ⟶ IT: — | ES: Jesús
21 Ἰησοῦς· = Jesus: (Jesus/Joshua) ⟶ IT: Gesù | ES: Jesús
22 λύσατε = do unbind (to loose) ⟶ IT: Scioglietelo | ES: Desatadle
23 αὐτὸν = him (he/she/it/self) ⟶ IT: Scioglietelo | ES: Desatadle
24 καὶ = and ⟶ IT: e | ES: y
25 ἄφετε = do allow (to release) ⟶ IT: lasciatelo | ES: dejadle
26 αὐτὸν = him (he/she/it/self) ⟶ IT: lasciatelo | ES: dejadle
27 ὑπάγειν = to go. (to go) ⟶ IT: andare | ES: ir
```
출력:
```
43:1:1 {Au|1} {commencement|2} {était|3} {la|4} {Parole|5}, {et|6} {la|7} {Parole|8} {était|9} {auprès de|10} {Dieu|12}, {et|13} {la|16} {Parole|17} {était|15} {Dieu|14}.
1:38:27 {Et il arriva|1} {au temps|2} {de son accouchement|3}, {et voici|4}, des {jumeaux|5} étaient {dans son ventre|6}.
43:1:36 {Et|1} {ayant fixé les yeux sur|2} {Jésus|4} {qui marchait|5}, {il dit|6} : {Voici|7} {l|8}'{Agneau|9} {de Dieu|11}.
43:11:44 {Le|3} {mort|4} {sortit|2}, {les|6} {pieds|7} {et|8} {les|9} {mains|10} {liés|5} {de bandes|11}, {et|12} {son|15} {visage|14} {était enveloppé|17} {d'un linge|16}. {Jésus|21} {leur|19} {dit|18} : {Déliez|22}-{le|23}, {et|24} {laissez|25}-{le|26} {aller|27}.
```
(실제 출력에는 ``` 를 쓰지 않는다.)
