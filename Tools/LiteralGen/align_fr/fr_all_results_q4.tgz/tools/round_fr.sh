#!/bin/bash
# [2026-11-17 fr] 프랑스어 본작업 한 차례: 병합 전 DB 복사 → 병합(구조 검사 포함) → 누락 확인 → 경고 목록 → 백업
# 사용: tools/round_fr.sh 차례번호 시작묶음 끝묶음      예) tools/round_it.sh 1 1 100
set -e
cd /home/claude/integ/align
Q=$1; A=$2; B=$3
O="--original src/OriginalText_cur.sqlite --lang fr --literal-db src_fr/Literal_fr.sqlite --manifest packets/fr_all/manifest.jsonl --flags src/edition_flags_v2.json"
F=""; miss=0
for i in $(seq -f "%04g" $A $B); do f=results/fr_all/p$i.txt; [ -s $f ] || { echo "결과 파일 없음: $f"; miss=1; }; F="$F $f"; done
[ $miss = 0 ] || { echo "파일 누락으로 중단(병합하지 않음)"; exit 3; }
cp work/Literal_fr_v1.sqlite work/Literal_fr_v1_pre_q$Q.sqlite
python3 -I tools/merge.py $O --base src_fr/Literal_fr.sqlite --target work/Literal_fr_v1.sqlite --fail-out results/fr_all_fails_q$Q.tsv $F 2>&1 | tail -4
python3 -I tools/check.py $O $F 2>/dev/null | grep '^합격' || true
python3 -I - $A $B <<'PY'
import sys, json
a, b = int(sys.argv[1]), int(sys.argv[2])
want = {}
for l in open("packets/fr_all/manifest.jsonl", encoding="utf-8"):
    d = json.loads(l); n = int(d["packet"][1:5])
    if a <= n <= b: want[d["ref"]] = d["packet"]
got = set()
for n in range(a, b + 1):
    for l in open("results/fr_all/p%04d.txt" % n, encoding="utf-8"):
        if l.strip(): got.add(l.split(" ", 1)[0])
print("요청 절", len(want), "/ 누락", [(r, p) for r, p in want.items() if r not in got])
PY
python3 -I tools/warn.py $O --hint IT=src_fr/Literal_it.sqlite --hint ES=src_fr/Literal_es.sqlite --hold it_pilot/hold_refs.txt --out results/fr_all_warn_q$Q.tsv $F
tar czf /mnt/user-data/outputs/fr_all_results.tgz results/fr_all results/fr_all_fails_*.tsv results/fr_all_warn_*.tsv work/Literal_fr_v1.sqlite fr_pilot prompt_fr.md tools/*.py tools/*.sh
md5sum /mnt/user-data/outputs/fr_all_results.tgz
