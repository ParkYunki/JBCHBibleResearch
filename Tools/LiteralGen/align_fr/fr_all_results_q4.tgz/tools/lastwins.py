"""결과 파일 정리: 모델이 '정정'하며 같은 절을 다시 쓴 경우 마지막 줄만 남긴다. 형식 밖 줄은 버린다.
사용: python3 -I tools/lastwins.py OUT_DIR files..."""
import sys, re, pathlib
out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
pat = re.compile(r'^(\d+:\d+:\d+) \S')
for f in sys.argv[2:]:
    p = pathlib.Path(f); last = {}; order = []
    for line in p.read_text(encoding='utf-8').splitlines():
        m = pat.match(line.strip().strip('`'))
        if not m: continue
        ref = m.group(1)
        if ref not in last: order.append(ref)
        last[ref] = line.strip()
    (out / p.name).write_text(''.join(last[r] + '\n' for r in order), encoding='utf-8')
