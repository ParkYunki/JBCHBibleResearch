"""정답 작업용 간결 보기. python3 -I tools/view.py --original src/OriginalText.sqlite 43:1:1 43:1:2 ... | --refs file
원어는 생략하고 n=translation_en(gloss)만 한 줄로 보인다(--orig 로 원어 포함)."""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--original", required=True)
ap.add_argument("--refs")
ap.add_argument("--orig", action="store_true")
ap.add_argument("refs_inline", nargs="*")
a = ap.parse_args()
src = L.Source(a.original)
lits, words = src.literals(), src.words()
refs = [L.parse_ref(x) for x in a.refs_inline]
if a.refs:
    for line in open(a.refs, encoding="utf-8"):
        t = line.split()
        if t and not t[0].startswith("#"):
            refs.append(L.parse_ref(t[0]))
for r in refs:
    print(f"{L.ref_str(*r)} {lits[r]}")
    parts = []
    for w in words[r]:
        m = w["tr"] or "-"
        if w["gloss"] and w["gloss"].lower() != w["tr"].lower():
            m += f"({w['gloss']})"
        if a.orig:
            m = L.clean_orig(w["orig"]) + " " + m
        parts.append(f"{w['n']}={m}")
    print("   " + " | ".join(parts))
