#!/bin/bash
# usage: round.sh Q A B   (merge packets A..B as round Q, check, missing, backup)
set -e
cd /home/claude/integ/align
Q=$1; A=$2; B=$3
cp work/Literal_zh_v1.sqlite work/Literal_zh_v1_pre_q$Q.sqlite
F=$(for i in $(seq -f "%04g" $A $B); do echo results/zh_all/p$i.txt; done)
python3 -I tools/merge.py --original src/OriginalText_cur.sqlite --lang zh --literal-db src/Literal_zh.sqlite --base src/Literal_zh.sqlite --target work/Literal_zh_v1.sqlite --manifest packets/zh_all/manifest.jsonl --flags src/edition_flags_v2.json --fail-out results/zh_all_fails_q$Q.tsv $F 2>&1 | tail -4
python3 -I tools/check.py --original src/OriginalText_cur.sqlite --lang zh --literal-db src/Literal_zh.sqlite --manifest packets/zh_all/manifest.jsonl --flags src/edition_flags_v2.json $F 2>&1 | head -1
python3 -I - $A $B <<'P'
import json,re,sys
A,B=int(sys.argv[1]),int(sys.argv[2]); want={}
for l in open('packets/zh_all/manifest.jsonl'):
    m=json.loads(l); n=int(re.search(r'(\d+)',str(m['packet'])).group(1))
    if A<=n<=B: want[m['ref']]=n
got=set()
for i in range(A,B+1):
    for x in open(f'results/zh_all/p{i:04d}.txt'):
        if x.strip(): got.add(x.split(' ',1)[0])
print('누락',[(r,n) for r,n in want.items() if r not in got])
P
tar czf /mnt/user-data/outputs/zh_all_results.tgz results/zh_all results/zh_all_fails_*.tsv work/Literal_zh_v1.sqlite
md5sum /mnt/user-data/outputs/zh_all_results.tgz
