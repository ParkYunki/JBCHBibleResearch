"""[zh] 재실행 결과를 ChatGPT 검수 판정(맞는 구간)과 비교한다. 사용: python3 -I tools/cmp_review.py RESULT_DIR MANIFEST REVIEW_TSV..."""
import sys, glob, collections, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L, check as C
rd, man, *revs = sys.argv[1:]
src = L.Source('src/OriginalText_cur.sqlite', 'zh', 'src/Literal_zh.sqlite'); lits, words = src.literals(), src.words()
ex = L.load_excluded('src/edition_flags_v2.json')
ok, fails, st = C.check_files(sorted(glob.glob(os.path.join(rd, 'p*.txt'))), lits, words, C.load_manifest(man), True, 0, 'cjk', ex)
print(f"검사: 합격 {len(ok)} / 불합격 {len(fails)} / 짝 비율 {st['aligned']/max(1,st['words'])*100:.1f}%")
for r in sorted(fails): print('  불합격', L.ref_str(*r), '; '.join(fails[r]))
agree = collections.Counter(); miss = []
for fn in revs:
    for l in open(fn, encoding='utf-8'):
        p = l.rstrip('\n').split('\t')
        if len(p) < 5 or p[0] == '요약': continue
        r = L.parse_ref(p[0]); n = int(p[1]); want = p[3]
        if r not in ok: agree['불합격절'] += 1; continue
        got = {w + 1: ph for w, ph, s in ok[r]}.get(n, '—')
        k = 'ok' if got == want else 'diff'
        agree[(p[2], k)] += 1
        if k == 'diff': miss.append((p[0], n, p[2], want, got))
print(dict(agree))
for m in miss: print('  다름', *m)
