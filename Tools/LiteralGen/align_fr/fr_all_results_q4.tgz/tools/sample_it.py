"""[it] 차례 표본 점검용: 합격 절에서 무작위 N절을 뽑아 '구간=원어 뜻' 형태로 보여 준다. 읽기 전용."""
import sys, random, re
sys.path.insert(0, "tools"); import alignlib as L
a, b, n, seed = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
src = L.Source("src/OriginalText_cur.sqlite", "it", "src_it/Literal_it.sqlite"); lits, words = src.literals(), src.words()
res = {}
for i in range(a, b + 1):
    for l in open("results/it_all/p%04d.txt" % i, encoding="utf-8"):
        if l.strip():
            h, _, m = l.rstrip("\n").partition(" "); r = L.parse_ref(h)
            if r and re.sub(r"\{([^{}|]*)\|[0-9,]+\}", r"\1", m) == lits.get(r): res[r] = m
random.seed(seed)
for r in sorted(random.sample(sorted(res), n)):
    m = res[r]; used = {int(x) for g in re.findall(r"\|([0-9,]+)\}", m) for x in g.split(",")}
    def rep(mo):
        ns = [int(x) for x in mo.group(2).split(",")]
        return "{" + mo.group(1) + "=" + "+".join((words[r][k - 1]["tr"].strip() or words[r][k - 1]["gloss"])[:14] for k in ns if 1 <= k <= len(words[r])) + "}"
    print(L.ref_str(*r), re.sub(r"\{([^{}|]*)\|([0-9,]+)\}", rep, m))
    un = [f"{w['n']}:{(w['tr'].strip() or w['gloss'])[:14]}" for w in words[r] if w["n"] not in used and "<obj.>" not in w["tr"]]
    if un: print("   짝없음:", " / ".join(un))
