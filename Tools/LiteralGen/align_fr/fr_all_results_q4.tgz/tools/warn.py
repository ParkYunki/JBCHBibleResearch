"""[2026-11-12 it] 낱말 맞춤 결과의 '문제 후보' 목록을 만든다. 결과를 고치지 않고 목록(TSV)만 쓴다. 불합격 사유가 아니라 검수 대상이다.
사용: python3 -I tools/warn.py --original O --lang it --literal-db L_it --manifest M --flags F
        --hint ES=Literal_es.sqlite --hint EN=Literal_en.sqlite [--hold hold.txt] --out warn.tsv 결과파일...
경고 종류
  W1 뒤바뀜의심   : 이 단어의 구간이 '다른 번호'의 힌트와 철자가 비슷하고, 제 번호의 힌트와는 비슷하지 않다(첫 번째 --hint 기준)
  W2 힌트없는짝   : 어떤 힌트 언어에도 짝이 없는데 결과에는 짝이 있다
  W3 짝누락       : 모든 힌트 언어에 짝이 있는데 결과에 짝이 없다(제외 단어·보류 절 제외)
  W4 반복순서     : 같은 구간 글자가 문장에 두 번 이상 나오고, 그 자리들에 붙은 원어 번호 순서가 문장 순서와 반대다
  W5 제외절잔여   : 제외 단어가 있는 절에서 4글자 이상 낱말이 3개 이상 감싸이지 않고 남았다
구조 검사(check.py)를 통과한 절만 본다. 보류 절(--hold)에서는 힌트를 쓰는 W1·W2·W3 을 내지 않는다.
요약 줄의 비율은 경고 건수 / 검사한 행 수이며, W3·W5 는 행이 아니므로 참고값이다."""
import argparse, os, sys, re, unicodedata, difflib, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L
import check as C


def norm(s):
    return "".join(ch for ch in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(ch) != "Mn")


def toks(s):
    return [t for t in re.findall(r"[^\W\d_]+", norm(s)) if len(t) >= 4]


def similar(a, b):
    """두 구간에 철자가 비슷한 낱말(4글자 이상)이 있는가."""
    ta, tb = toks(a), toks(b)
    return any(x == y or difflib.SequenceMatcher(None, x, y).ratio() >= 0.8 for x in ta for y in tb)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True); ap.add_argument("--lang", required=True)
    ap.add_argument("--literal-db", required=True); ap.add_argument("--manifest")
    ap.add_argument("--flags"); ap.add_argument("--hold")
    ap.add_argument("--hint", action="append", default=[], metavar="LABEL=DB")
    ap.add_argument("--out", required=True); ap.add_argument("files", nargs="+")
    a = ap.parse_args()
    src = L.Source(a.original, a.lang, a.literal_db)
    lits, words = src.literals(), src.words()
    excluded = L.load_excluded(a.flags)
    mode = "cjk" if a.lang == "zh" else "space"
    ok, fails, _ = C.check_files(a.files, lits, words, C.load_manifest(a.manifest), True, 0.0, mode, excluded)
    hold = set()
    if a.hold:
        for no, line in enumerate(open(a.hold, encoding="utf-8-sig"), 1):
            if line.startswith("#") or not line.strip(): continue
            r = L.parse_ref(line.split()[0])
            if not r:
                raise SystemExit(f"{a.hold} {no}행을 절로 읽을 수 없습니다")
            hold.add(r)
    hints = []
    for spec in a.hint:
        label, sep, path = spec.partition("=")
        if not sep or not label or not path:
            raise SystemExit(f"--hint 형식 오류: {spec!r} (LABEL=DB)")
        d = collections.defaultdict(dict)
        for b, c, v, wi, ph in L.ro_connect(path).execute("SELECT book_id,chapter,verse,word_index,phrase FROM WordAlignment"):
            d[(b, c, v)][wi] = ph
        hints.append((label, d))
    out = []
    for r in sorted(ok):
        rows = {wi: (ph, st) for wi, ph, st in ok[r]}
        text = lits[r]; exc = excluded.get(r, frozenset())
        hv = [(label, d.get(r, {})) for label, d in hints]
        if hv and r not in hold:
            first = hv[0][1]
            for wi, (ph, st) in rows.items():
                own = first.get(wi)
                if own is not None and not similar(ph, own):
                    other = [j for j, hp in first.items() if j != wi and hp != own and similar(ph, hp)]
                    if other:
                        out.append((r, wi + 1, "W1 뒤바뀜의심", f"{ph!r} ~ {hv[0][0]}[{min(other)+1}]={first[min(other)]!r}, 제 힌트={own!r}"))
                if all(wi not in d for _, d in hv):
                    out.append((r, wi + 1, "W2 힌트없는짝", repr(ph)))
            for w in words[r]:
                wi = w["n"] - 1
                if wi not in rows and w["n"] not in exc and all(wi in d for _, d in hv):
                    out.append((r, w["n"], "W3 짝누락", " / ".join(f"{label}={d[wi]!r}" for label, d in hv)))
        byphrase = collections.defaultdict(list)
        for wi, (ph, st) in rows.items():
            byphrase[ph].append((st, wi))
        for ph, lst in byphrase.items():
            starts = sorted(set(s for s, _ in lst))
            if len(starts) >= 2:
                first_w = [min(w for s, w in lst if s == st) for st in starts]
                if first_w != sorted(first_w):
                    out.append((r, first_w[0] + 1, "W4 반복순서", f"{ph!r} 자리 {starts} ← 번호 {[w+1 for w in first_w]}"))
        if exc:
            cov = [False] * len(text)
            for ph, st in rows.values():
                for i in range(st, st + len(ph)): cov[i] = True
            left = [m.group(0) for m in re.finditer(r"[^\W\d_]{4,}", text) if not any(cov[m.start():m.end()])]
            if len(left) >= 3:
                out.append((r, 0, "W5 제외절잔여", " ".join(left[:8])))
    with open(a.out, "w", encoding="utf-8") as f:
        f.write("절\t단어번호\t경고\t내용\n")
        for r, n, kind, msg in out:
            f.write(f"{L.ref_str(*r)}\t{n}\t{kind}\t{msg}\n")
    nrows = sum(len(v) for v in ok.values())
    cnt = collections.Counter(k for _, _, k, _ in out)
    print(f"검사한 절 {len(ok)} (구조 불합격 {len(fails)}절 제외) / 행 {nrows} / 경고 {len(out)} ({len(out)/max(nrows,1)*100:.1f}%) / {dict(cnt)}")


if __name__ == "__main__":
    main()
