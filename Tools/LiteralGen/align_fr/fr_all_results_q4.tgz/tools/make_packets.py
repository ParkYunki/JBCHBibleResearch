"""패킷(모델 입력) 생성.

전체:   python3 -I tools/make_packets.py --original src/OriginalText.sqlite --out packets/ko
목록만: python3 -I tools/make_packets.py --original ... --out packets/retry1 --refs retry.txt
옵션:   --size 50 (절/패킷), --lang ko, --literal-db (ko 외 언어)

출력
- <out>/p0001.txt ...  : 지시문 뒤에 그대로 붙이는 입력 본문
- <out>/manifest.jsonl : {ref, packet, nwords, wfp, tfp} — 병합 시 데이터 변경 감지용
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402


def load_refs(path):
    refs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            tok = line.split()
            if tok and not tok[0].startswith("#"):
                r = L.parse_ref(tok[0])
                if r is None:
                    raise SystemExit(f"잘못된 절 표기: {tok[0]}")
                refs.append(r)
    return refs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True)
    ap.add_argument("--lang", default="ko")
    ap.add_argument("--literal-db")
    ap.add_argument("--out", required=True)
    ap.add_argument("--size", type=int, default=50)
    ap.add_argument("--refs", help="절 목록 파일(줄마다 b:c:v). 없으면 전체")
    a = ap.parse_args()

    src = L.Source(a.original, a.lang, a.literal_db)
    lits = src.literals()
    words = src.words()
    if a.refs:
        refs = load_refs(a.refs)
    else:
        refs = sorted(set(lits) & set(words))
    skipped = [r for r in refs if r not in lits or r not in words]
    refs = [r for r in refs if r in lits and r in words]

    os.makedirs(a.out, exist_ok=True)
    manifest = []
    for i in range(0, len(refs), a.size):
        name = f"p{i // a.size + 1:04d}"
        chunk = refs[i:i + a.size]
        body = "\n\n".join(L.render_verse(r, lits[r], words[r]) for r in chunk)
        with open(os.path.join(a.out, name + ".txt"), "w", encoding="utf-8") as f:
            f.write(body + "\n")
        for r in chunk:
            manifest.append(dict(ref=L.ref_str(*r), packet=name, nwords=len(words[r]),
                                 wfp=L.words_fingerprint(words[r]), tfp=L.text_fingerprint(lits[r])))
    L.write_jsonl(os.path.join(a.out, "manifest.jsonl"), manifest)
    npk = (len(refs) + a.size - 1) // a.size
    chars = sum(os.path.getsize(os.path.join(a.out, f"p{k + 1:04d}.txt")) for k in range(npk))
    print(f"절 {len(refs)} / 패킷 {npk} / 본문 {chars:,} bytes / 건너뜀 {len(skipped)}")
    for r in skipped[:20]:
        print("  건너뜀(직역 또는 원어 없음):", L.ref_str(*r))


if __name__ == "__main__":
    main()
