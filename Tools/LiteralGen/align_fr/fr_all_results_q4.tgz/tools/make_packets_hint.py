"""영어 짝을 힌트로 붙인 다른 언어 패킷 생성.
사용(기존): python3 -I tools/make_packets_hint.py --original O --literal-db L_xx --en-db Literal_en --refs refs.txt --out DIR --per 10 [--label ES]

[2026-11-12 it] 다국어 힌트(선택 사항). --hint 를 하나라도 주면 새 방식으로 동작하고, 주지 않으면 기존 출력과 글자까지 같다.
  --hint EN=Literal_en.sqlite --hint ES=Literal_es.sqlite   (적은 순서 = 우선순위)
  --select all    : 준 힌트를 모두 쓴다. 짝이 없으면 '—'.            (H0: EN만 / H1: ES만 / H2: ES,EN)
  --select first  : 우선순위대로 '가는 구간'인 첫 힌트 하나만 쓴다. 없으면 힌트를 쓰지 않는다. (H3)
       가는 구간 = 낱말 수 <= --max-tokens 이고, 같은 구간을 쓰는 원어 단어 수 <= --max-share
  --hold FILE     : 이 절들은 기존 짝 힌트를 쓰지 않는다(원어 뜻풀이만). 제외 단어 표시는 그대로 한다.
  --flags         : 새 방식에서는 필수(없이 만들려면 --no-flags 를 명시).
  --cond NAME     : 조건 이름. meta.json 에 기록한다.
새 방식은 요청한 절이 하나라도 빠지면 오류로 끝나고(--allow-skip 으로 허용), 입력 파일 md5·인자·절 수를 OUT/meta.json 에 적는다."""
import argparse, os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L
ap = argparse.ArgumentParser()
ap.add_argument("--original", required=True); ap.add_argument("--literal-db", required=True)
ap.add_argument("--en-db"); ap.add_argument("--refs", required=True)
ap.add_argument("--out", required=True); ap.add_argument("--per", type=int, default=10)
ap.add_argument("--label", default="ES"); ap.add_argument("--lang", default="es")
ap.add_argument("--flags", help="[zh] edition_flags_v2.json — 제외 단어를 '(직역에 없음)'으로 표시")
ap.add_argument("--compact", action="store_true", help="[zh] 압축 형식: '번호 원어|뜻|EN짝', 제외 단어는 '|×'")
ap.add_argument("--hint", action="append", default=[], metavar="LABEL=DB", help="[it] 힌트 DB(여러 번 가능, 적은 순서가 우선순위)")
ap.add_argument("--select", choices=["all", "first"], default="all")
ap.add_argument("--max-tokens", type=int, default=3); ap.add_argument("--max-share", type=int, default=2)
ap.add_argument("--hold", help="[it] 기존 짝 힌트를 쓰지 않을 절 목록(한 줄에 책:장:절)")
ap.add_argument("--no-flags", action="store_true"); ap.add_argument("--allow-skip", action="store_true")
ap.add_argument("--cond", default="")
a = ap.parse_args()
if a.hint:
    if a.en_db or a.compact:
        raise SystemExit("--hint 는 --en-db/--compact 와 함께 쓸 수 없습니다")
    if not a.flags and not a.no_flags:
        raise SystemExit("--hint 방식에는 --flags 가 필요합니다(없이 만들려면 --no-flags)")
    if a.per < 1:
        raise SystemExit("--per 는 1 이상이어야 합니다")
elif not a.en_db:
    raise SystemExit("--en-db 또는 --hint 가 필요합니다")
elif a.hold or a.cond or a.no_flags or a.allow_skip or a.select != "all":
    raise SystemExit("--hold/--cond/--select/--no-flags/--allow-skip 는 --hint 방식에서만 씁니다")
src = L.Source(a.original, a.lang, a.literal_db)
lits, words = src.literals(), src.words()
excluded = L.load_excluded(a.flags)


def read_refs(path):
    """[it] 절 목록. '#' 주석과 빈 줄만 건너뛰고, 해석하지 못한 줄이 있으면 오류로 끝낸다(BOM 허용)."""
    out = []
    for no, line in enumerate(open(path, encoding="utf-8-sig"), 1):
        if line.startswith("#") or not line.strip(): continue
        r = L.parse_ref(line.split()[0])
        if not r:
            raise SystemExit(f"{path} {no}행을 절로 읽을 수 없습니다: {line.strip()[:40]!r}")
        out.append(r)
    return out


def manifest_line(r, name):
    return json.dumps({"ref": L.ref_str(*r), "packet": name, "nwords": len(words[r]),
                       "wfp": L.words_fingerprint(words[r]), "tfp": L.text_fingerprint(lits[r])}, ensure_ascii=False) + "\n"


def meaning(w):
    tr = w["tr"].strip(); g = w["gloss"].strip()
    m = tr if tr else "-"
    if g and g.lower() != tr.lower(): m += f" ({g})"
    return m


if a.hint:
    # ------------------------------------------------------------ [2026-11-12 it] 다국어 힌트
    import hashlib, collections

    def md5(path):
        h = hashlib.md5()
        with open(path, "rb") as f:
            for blk in iter(lambda: f.read(1 << 20), b""): h.update(blk)
        return h.hexdigest()

    hints = []  # [(label, path, {ref: {word_index: (phrase, start)}})]
    for spec in a.hint:
        label, sep, path = spec.partition("=")
        if not sep or not label or not path or label in ("제외", "보류절", "힌트 없음"):
            raise SystemExit(f"--hint 형식 오류: {spec!r} (LABEL=DB)")
        if any(label == h[0] for h in hints):
            raise SystemExit(f"--hint 라벨 중복: {label}")
        db = L.ro_connect(path); d = collections.defaultdict(dict)
        for b, c, v, wi, ph, st in db.execute("SELECT book_id,chapter,verse,word_index,phrase,start FROM WordAlignment"):
            d[(b, c, v)][wi] = (ph, st)
        hints.append((label, path, d))
    hold = set(read_refs(a.hold)) if a.hold else set()
    asked = read_refs(a.refs)
    if len(set(asked)) != len(asked):
        raise SystemExit("절 목록에 중복이 있습니다")
    skipped = [r for r in asked if r not in lits or r not in words]
    if skipped and not a.allow_skip:
        raise SystemExit("직역 또는 원어가 없는 절: " + " ".join(L.ref_str(*r) for r in skipped))
    refs = [r for r in asked if r in lits and r in words]
    os.makedirs(a.out, exist_ok=True)
    man = open(os.path.join(a.out, "manifest.jsonl"), "w", encoding="utf-8")
    stat = collections.Counter(); npk = 0
    for p in range(0, len(refs), a.per):
        name = "p%04d.txt" % (p // a.per + 1); npk += 1
        blocks = []
        for r in refs[p:p + a.per]:
            nw = len(words[r])
            per = []  # [(label, {wi: (phrase, start)}, Counter((phrase,start)))]
            for label, _, d in hints:
                # 범위 밖 번호와 제외 단어의 짝은 힌트로도, 구간 공유 수로도 세지 않는다
                rows = {wi: x for wi, x in d.get(r, {}).items() if 0 <= wi < nw and (wi + 1) not in excluded.get(r, ())}
                per.append((label, rows, collections.Counter(rows.values())))
            lines = [f"## {L.ref_str(*r)}", f"{a.label}: {lits[r]}"]
            for w in words[r]:
                wi = w["n"] - 1
                head = f"{w['n']} {L.clean_orig(w['orig'])} = {meaning(w)}"
                if w["n"] in excluded.get(r, ()):
                    lines.append(head + " ⟶ (직역에 없음: 짝 짓지 말 것)"); stat["제외"] += 1
                elif r in hold:
                    lines.append(head); stat["보류절"] += 1
                elif a.select == "all":
                    lines.append(head + " ⟶ " + " | ".join(f"{label}: {rows[wi][0] if wi in rows else '—'}" for label, rows, _ in per))
                    for label, rows, _ in per: stat[label if wi in rows else f"{label} 없음"] += 1
                else:
                    for label, rows, cnt in per:
                        x = rows.get(wi)
                        if x and len(x[0].split()) <= a.max_tokens and cnt[x] <= a.max_share:
                            lines.append(head + f" ⟶ {label}: {x[0]}"); stat[label] += 1
                            break
                    else:
                        lines.append(head); stat["힌트 없음"] += 1
            blocks.append("\n".join(lines))
            man.write(manifest_line(r, name))
        open(os.path.join(a.out, name), "w", encoding="utf-8").write("\n\n".join(blocks) + "\n")
    man.close()
    meta = {"cond": a.cond, "lang": a.lang, "label": a.label, "select": a.select,
            "max_tokens": a.max_tokens, "max_share": a.max_share, "per": a.per,
            "no_flags": a.no_flags, "allow_skip": a.allow_skip,
            "paths": {"original": a.original, "literal": a.literal_db, "refs": a.refs, "flags": a.flags, "hold": a.hold,
                      "hints": [f"{label}={path}" for label, path, _ in hints]},
            "asked": len(asked), "made": len(refs), "skipped": [L.ref_str(*r) for r in skipped], "packets": npk,
            "hold_in_refs": sum(1 for r in refs if r in hold), "word_stats": dict(stat),
            "md5": {"original": md5(a.original), "literal": md5(a.literal_db), "refs": md5(a.refs),
                    "flags": md5(a.flags) if a.flags else None, "hold": md5(a.hold) if a.hold else None,
                    "tool": md5(os.path.abspath(__file__)), "alignlib": md5(L.__file__),
                    **{f"hint_{label}": md5(path) for label, path, _ in hints}}}
    with open(os.path.join(a.out, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print(len(refs), "절", "/ 요청", len(asked), "/ 묶음", npk, "/", dict(stat))
    sys.exit(0)

en = L.ro_connect(a.en_db)
refs = []
for line in open(a.refs, encoding="utf-8"):
    if line.startswith("#") or not line.strip(): continue
    r = L.parse_ref(line.split()[0])
    if r and r in lits and r in words: refs.append(r)
os.makedirs(a.out, exist_ok=True)
man = open(os.path.join(a.out, "manifest.jsonl"), "w", encoding="utf-8")
for p in range(0, len(refs), a.per):
    name = "p%04d.txt" % (p // a.per + 1)
    blocks = []
    for r in refs[p:p + a.per]:
        al = dict(en.execute("SELECT word_index,phrase FROM WordAlignment WHERE book_id=? AND chapter=? AND verse=?", r).fetchall())
        if a.compact:
            lines = [f"@{L.ref_str(*r)}", f"{a.label}={lits[r]}"]
            for w in words[r]:
                m = (w["tr"].strip() or w["gloss"].strip() or "-").replace("|", "/")
                o = L.clean_orig(w["orig"])
                if w["n"] in excluded.get(r, ()):
                    lines.append(f"{w['n']} {o}|×")
                else:
                    e = al.get(w["n"] - 1)
                    lines.append(f"{w['n']} {o}|{m}" + (f"|{e}" if e else ""))
            blocks.append("\n".join(lines))
            man.write(json.dumps({"ref": L.ref_str(*r), "packet": name, "nwords": len(words[r]),
                                  "wfp": L.words_fingerprint(words[r]), "tfp": L.text_fingerprint(lits[r])}, ensure_ascii=False) + "\n")
            continue
        lines = [f"## {L.ref_str(*r)}", f"{a.label}: {lits[r]}"]
        for w in words[r]:
            tr = w["tr"].strip(); g = w["gloss"].strip()
            m = tr if tr else "-"
            if g and g.lower() != tr.lower(): m += f" ({g})"
            if w["n"] in excluded.get(r, ()):
                lines.append(f"{w['n']} {L.clean_orig(w['orig'])} = {m} ⟶ (직역에 없음: 짝 짓지 말 것)")
            else:
                lines.append(f"{w['n']} {L.clean_orig(w['orig'])} = {m} ⟶ EN: {al.get(w['n'] - 1, '—')}")
        blocks.append("\n".join(lines))
        man.write(json.dumps({"ref": L.ref_str(*r), "packet": name, "nwords": len(words[r]),
                              "wfp": L.words_fingerprint(words[r]), "tfp": L.text_fingerprint(lits[r])}, ensure_ascii=False) + "\n")
    open(os.path.join(a.out, name), "w", encoding="utf-8").write("\n\n".join(blocks) + "\n")
print(len(refs), "절")
