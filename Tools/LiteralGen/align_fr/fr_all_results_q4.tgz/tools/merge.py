"""검사 통과한 결과를 WordAlignment 테이블에 병합(작업 사본에서만).

python3 -I tools/merge.py --original src/OriginalText.sqlite --base src/Literal_ko.sqlite \
    --target work/Literal_ko.sqlite [--manifest packets/ko/manifest.jsonl] [--fail-out fails.tsv] 결과파일...

- --target 이 없으면 --base 를 복사해 만든다. 원본(--base, --original)과 같은 파일이거나
  /mnt/ 아래(기기 마운트·업로드 사본)면 거부한다.
- 절 단위 교체: 그 절의 기존 행을 지우고 새 행을 넣는다(한 트랜잭션). 불합격 절은 건드리지 않는다.
- 끝나면 표 전체를 앱 표시 규칙(phrase == literal[start:start+len])으로 재검증하고 integrity_check.

스키마(고정):
CREATE TABLE WordAlignment(
  book_id INTEGER NOT NULL, chapter INTEGER NOT NULL, verse INTEGER NOT NULL,
  word_index INTEGER NOT NULL, phrase TEXT NOT NULL, start INTEGER NOT NULL,
  PRIMARY KEY(book_id, chapter, verse, word_index)
) WITHOUT ROWID
"""
import argparse
import os
import shutil
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402
import check as C  # noqa: E402

DDL = """CREATE TABLE WordAlignment(
  book_id INTEGER NOT NULL,
  chapter INTEGER NOT NULL,
  verse INTEGER NOT NULL,
  word_index INTEGER NOT NULL,
  phrase TEXT NOT NULL,
  start INTEGER NOT NULL,
  PRIMARY KEY(book_id, chapter, verse, word_index)
) WITHOUT ROWID"""
COLS = ["book_id", "chapter", "verse", "word_index", "phrase", "start"]


def ensure_table(con):
    row = con.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='WordAlignment'").fetchone()
    if row is None:
        con.execute(DDL)
        return "생성"
    cols = [r[1] for r in con.execute("PRAGMA table_info(WordAlignment)")]
    pk = [r[1] for r in sorted(con.execute("PRAGMA table_info(WordAlignment)"), key=lambda r: r[5]) if r[5]]
    if cols != COLS or pk != COLS[:4] or "WITHOUT ROWID" not in row[0].upper():
        raise SystemExit(f"기존 WordAlignment 스키마가 다릅니다: {row[0]}")
    return "기존"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True)
    ap.add_argument("--lang", default="ko")
    ap.add_argument("--literal-db")
    ap.add_argument("--base", required=True, help="번들 Literal_<lang>.sqlite 의 사본(읽기 전용)")
    ap.add_argument("--target", required=True, help="쓰기 대상 작업 사본")
    ap.add_argument("--manifest")
    ap.add_argument("--fail-out")
    ap.add_argument("--no-boundary", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--flags", help="[zh] edition_flags_v2.json — 제외 단어에 짝이 있으면 불합격")
    ap.add_argument("files", nargs="+")
    a = ap.parse_args()

    tgt = os.path.realpath(a.target)
    for p in (a.base, a.original, a.literal_db):
        if p and os.path.exists(p) and os.path.realpath(p) == tgt:
            raise SystemExit("대상이 원본과 같은 파일입니다")
    if tgt.startswith("/mnt/"):
        raise SystemExit("대상이 /mnt/ 아래입니다(기기·업로드 경로에는 쓰지 않음)")

    src = L.Source(a.original, a.lang, a.literal_db)
    lits, words = src.literals(), src.words()
    mode = "cjk" if a.lang == "zh" else "space"
    L.require_flags(a.lang, a.flags)
    excluded = L.load_excluded(a.flags)
    ok, fails, st = C.check_files(a.files, lits, words, C.load_manifest(a.manifest), not a.no_boundary,
                                  0.0, mode, excluded)
    print(f"검사: 합격 {len(ok)}절 / 불합격 {len(fails)}절 / 형식오류 줄 {st['bad_lines']}")
    if a.fail_out:
        with open(a.fail_out, "w", encoding="utf-8") as f:
            for r in sorted(fails):
                f.write(f"{L.ref_str(*r)}\t{'; '.join(fails[r])}\n")
    if a.dry_run:
        return

    if not os.path.exists(tgt):
        os.makedirs(os.path.dirname(tgt), exist_ok=True)
        shutil.copyfile(a.base, tgt)
        os.chmod(tgt, 0o644)
        print(f"작업 사본 생성: {tgt}")
    con = sqlite3.connect(tgt)
    try:
        con.execute("PRAGMA foreign_keys=OFF")
        with con:
            print("테이블:", ensure_table(con))
            n = 0
            for (b, c, v), rows in sorted(ok.items()):
                con.execute("DELETE FROM WordAlignment WHERE book_id=? AND chapter=? AND verse=?", (b, c, v))
                con.executemany("INSERT INTO WordAlignment VALUES(?,?,?,?,?,?)",
                                [(b, c, v, wi, ph, s) for wi, ph, s in rows])
                n += len(rows)
        print(f"병합: {len(ok)}절 {n}행")
        # 재검증(앱 표시 규칙 + 단어 범위)
        bad = 0
        total = 0
        for b, c, v, wi, ph, s in con.execute("SELECT * FROM WordAlignment"):
            total += 1
            t = lits.get((b, c, v))
            nw = len(words.get((b, c, v), []))
            if t is None or not (0 <= wi < nw) or not ph or t[s:s + len(ph)] != ph or s < 0:
                bad += 1
            elif (wi + 1) in excluded.get((b, c, v), ()):
                bad += 1
        ic = con.execute("PRAGMA integrity_check").fetchone()[0]
        nv = con.execute("SELECT count(*) FROM (SELECT DISTINCT book_id,chapter,verse FROM WordAlignment)").fetchone()[0]
        print(f"재검증: 전체 {total}행 / {nv}절 / 표시규칙 위반 {bad} / integrity_check={ic}")
        if bad or ic != "ok":
            sys.exit(2)
    finally:
        con.close()


if __name__ == "__main__":
    main()
