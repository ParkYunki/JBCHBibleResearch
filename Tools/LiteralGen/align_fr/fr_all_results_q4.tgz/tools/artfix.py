"""규칙 4·6 후처리: 그리스어 관사(G3588)·히브리어 목적격 표지(H0853)가 '그'/'이' 어절 없이
다른 단어와 같은 구간을 함께 쓰면 그 짝을 지운다(관사·표지가 조사로만 나타난 경우).
사용: python3 -I tools/artfix.py --original OriginalText.sqlite --target Literal_ko.sqlite"""
import sqlite3, collections, argparse
ap = argparse.ArgumentParser(); ap.add_argument('--original', required=True); ap.add_argument('--target', required=True)
a = ap.parse_args()
o = sqlite3.connect(f'file:{a.original}?immutable=1', uri=True)
w = sqlite3.connect(a.target)
codes = collections.defaultdict(list)
for b, c, v, s in o.execute('select book_id,chapter,verse,strong_code from original_words order by book_id,chapter,verse,word_order,rowid'):
    codes[(b, c, v)].append(s)
rows = collections.defaultdict(list)
for b, c, v, i, p, s in w.execute('select book_id,chapter,verse,word_index,phrase,start from WordAlignment'):
    rows[(b, c, v)].append((i, p, s))
todo = []; cnt = collections.Counter()
for k, lst in rows.items():
    spans = collections.Counter((p, s) for i, p, s in lst)
    for i, p, s in lst:
        sc = codes[k][i]
        if sc in ('G3588', 'H0853') and not (p in ('그', '이') or p.startswith('그 ') or p.startswith('이 ')) and spans[(p, s)] > 1:
            todo.append((k[0], k[1], k[2], i)); cnt[sc] += 1
with w:
    for t in todo:
        w.execute('delete from WordAlignment where book_id=? and chapter=? and verse=? and word_index=?', t)
w.execute('VACUUM')
print('삭제', dict(cnt), '남은 행', w.execute('select count(*) from WordAlignment').fetchone()[0], w.execute('pragma integrity_check').fetchone()[0])
