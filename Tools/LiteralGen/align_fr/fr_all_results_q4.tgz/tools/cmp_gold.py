"""[zh] 결과 디렉터리를 zh_gold.jsonl과 단어 단위로 비교. 사용: python3 -I tools/cmp_gold.py RESULT_DIR MANIFEST"""
import sys, glob, json, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L, check as C
rd, man = sys.argv[1:3]
src = L.Source('src/OriginalText_cur.sqlite', 'zh', 'src/Literal_zh.sqlite'); lits, words = src.literals(), src.words()
ex = L.load_excluded('src/edition_flags_v2.json')
ok, fails, st = C.check_files(sorted(glob.glob(os.path.join(rd, 'p*.txt'))), lits, words, C.load_manifest(man), True, 0, 'cjk', ex)
print(f"검사: 합격 {len(ok)} / 불합격 {len(fails)} / 짝 비율 {st['aligned']/max(1,st['words'])*100:.1f}%")
for r in sorted(fails): print('  불합격', L.ref_str(*r), '; '.join(fails[r])[:150])
gold = {L.parse_ref(j['ref']): {w: (p, s) for w, p, s in j['rows']} for j in map(json.loads, open('zh_gold.jsonl', encoding='utf-8'))}
c = collections.Counter()
for r, rows in ok.items():
    g = gold.get(r)
    if g is None: continue
    m = {w: (p, s) for w, p, s in rows}
    for w in range(len(words[r])):
        if (w + 1) in ex.get(r, ()): continue
        a, b = m.get(w), g.get(w)
        c['same' if a == b else ('both_none' if a is None and b is None else 'diff')] += 1
tot = sum(c.values())
print(dict(c), f"일치율 {c['same']/max(1,tot)*100:.1f}%")
