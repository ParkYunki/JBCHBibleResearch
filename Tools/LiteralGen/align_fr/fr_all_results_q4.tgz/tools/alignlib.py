"""원어 단어 <-> 직역 문장 짝짓기(WordAlignment) 공통 모듈.

실행은 항상 `python3 -I tools/<script>.py ...` (이 모듈은 각 스크립트가 sys.path에 직접 넣는다).

핵심 규약
- 단어 번호 n(지시문·패킷·결과 표기) = word_index + 1.
  word_index = 앱 배열 위치(0부터) = `ORDER BY word_order, rowid` 순서.
  앱(OriginalTextStore.words)은 `ORDER BY word_order ASC`이며 커버링 인덱스
  idx_original_words_verse(book_id,chapter,verse,word_order)를 타므로 동순위는 rowid 순이다.
  (word_order 중복 17쌍 = 신30:16, 삿16:14, 삼하23:33, 왕하25:3)
- start = 직역 문장 안 Unicode scalar 0-based 오프셋(Python str index).
- 결과 표기(마크업): 직역 문장을 그대로 옮기고 대응 구간만 `{구|n,n}`으로 감싼다.
  표기를 지운 문장은 원래 직역과 글자 하나까지 같아야 한다.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import unicodedata

TAG_RE = re.compile(r"\{([^{}|]*)\|([^{}]*)\}")
REF_RE = re.compile(r"^(\d{1,2}):(\d{1,3}):(\d{1,3})$")
LEAD_PUNCT = set("\"'“‘([「『<¿¡«")
TRAIL_PUNCT = set(".,;:!?\"'”’)]」』>…—~»")
CANTILLATION = re.compile("[֑-ֽ֯׀׃-ׇ]")  # 히브리어 억양부호·메텍 등(모음점은 유지)


def ro_connect(path: str) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{path}?immutable=1", uri=True)


def ref_str(b: int, c: int, v: int) -> str:
    return f"{b}:{c}:{v}"


def parse_ref(s: str):
    m = REF_RE.match(s)
    if not m:
        return None
    return tuple(int(x) for x in m.groups())


# ---------------------------------------------------------------- 데이터
class Source:
    """원어 단어 + 직역 문장. lang='ko'면 OriginalText.LiteralTranslation, 그 밖은 Literal_<lang>.LiteralText."""

    def __init__(self, original_db: str, lang: str = "ko", literal_db: str | None = None):
        self.lang = lang
        self.oc = ro_connect(original_db)
        if lang == "ko":
            self.lc = self.oc
            self.lit_sql = ("SELECT book_id,chapter,verse,literal_translation FROM LiteralTranslation", )
        else:
            if not literal_db:
                raise SystemExit("lang != ko 이면 --literal-db 가 필요합니다")
            self.lc = ro_connect(literal_db)
            self.lit_sql = ("SELECT book_id,chapter,verse,text FROM LiteralText", )

    def literals(self) -> dict:
        out = {}
        for b, c, v, t in self.lc.execute(self.lit_sql[0]):
            if isinstance(t, str) and t.strip():
                out[(b, c, v)] = t
        return out

    def words(self) -> dict:
        """{(b,c,v): [dict(n, orig, tr, gloss, strong, morph)]}  — 앱 배열 순서."""
        out: dict = {}
        q = ("SELECT book_id,chapter,verse,original_text,translation_en,gloss_en,strong_code,morph_code "
             "FROM original_words ORDER BY book_id,chapter,verse,word_order,rowid")
        for b, c, v, o, tr, g, s, m in self.oc.execute(q):
            lst = out.setdefault((b, c, v), [])
            lst.append(dict(n=len(lst) + 1, orig=o, tr=tr or "", gloss=g or "", strong=s, morph=m))
        return out


def words_fingerprint(ws) -> str:
    h = hashlib.sha1()
    for w in ws:
        h.update((w["orig"] + "\x1f" + w["strong"] + "\x1e").encode())
    return h.hexdigest()[:12]


def text_fingerprint(t: str) -> str:
    return hashlib.sha1(t.encode()).hexdigest()[:12]


# ---------------------------------------------------------------- 패킷
def clean_orig(o: str) -> str:
    o = CANTILLATION.sub("", o)
    return unicodedata.normalize("NFC", o)


def render_verse(ref, literal: str, ws) -> str:
    lines = [f"## {ref_str(*ref)}", f"KO: {literal}"]
    for w in ws:
        tr = w["tr"].strip()
        g = w["gloss"].strip()
        meaning = tr if tr else "-"
        if g and g.lower() != tr.lower():
            meaning += f" ({g})"
        lines.append(f"{w['n']} {clean_orig(w['orig'])} = {meaning}")
    return "\n".join(lines)


# ---------------------------------------------------------------- 결과 파싱·검증
PUNCT = LEAD_PUNCT | TRAIL_PUNCT | {"/", "-", "·"}


def boundary_error(text: str, start: int, phrase: str):
    """어절 경계 규칙. 위반이면 사유 문자열, 아니면 None.
    - 시작: 문장 처음이거나 바로 앞 글자가 공백/문장부호
    - 끝: 문장 끝이거나 바로 뒤 글자가 공백/문장부호
    - 구는 공백·문장부호로 시작하지 않고, 공백·문장부호로 끝나지 않는다
      (단, 구 안에서 짝이 맞는 ')' ']'로 끝나는 것은 허용: 예 `것들(소유)`)."""
    end = start + len(phrase)
    if start > 0 and not (text[start - 1].isspace() or text[start - 1] in PUNCT):
        return "시작이어절중간"
    if end < len(text) and not (text[end].isspace() or text[end] in PUNCT):
        return "끝이어절중간"
    if phrase[0].isspace() or phrase[0] in PUNCT:
        return "부호로시작"
    last = phrase[-1]
    if last.isspace():
        return "공백으로끝"
    if last in PUNCT:
        pair = {")": "(", "]": "["}.get(last)
        if not (pair and phrase.count(pair) >= phrase.count(last)):
            return "부호로끝"
    return None


# [2026-11-11 zh] 띄어쓰기가 없는 언어(중국어)의 구간 규칙: 어절 경계 대신 문장부호 경계만 본다.
CJK_LEAD = set("「『（〔《〈“‘")
CJK_TRAIL = set("，。、；：！？」』）〕》〉”’…—")
CJK_PUNCT = CJK_LEAD | CJK_TRAIL | PUNCT


def boundary_error_cjk(text: str, start: int, phrase: str):
    """중국어 구간 규칙. 위반이면 사유, 아니면 None.
    - 구는 공백·문장부호로 시작하지 않는다(여는 괄호 「『（〔《 포함).
    - 구는 공백·문장부호로 끝나지 않는다. 단, 구 안에 짝이 있는 닫는 괄호(」』）〕》)로 끝나는 것은 허용.
    글자 단위로 자르므로 '어절 중간' 검사는 하지 않는다."""
    if phrase[0].isspace() or phrase[0] in CJK_PUNCT:
        return "부호로시작"
    last = phrase[-1]
    if last.isspace():
        return "공백으로끝"
    if last in CJK_PUNCT:
        pair = {")": "(", "]": "[", "」": "「", "』": "『", "）": "（", "〕": "〔", "》": "《"}.get(last)
        if not (pair and phrase.count(pair) >= phrase.count(last)):
            return "부호로끝"
    return None


def parse_markup(marked: str):
    """마크업 -> (복원 문장, [(start, phrase, [n...])], 형식오류목록)."""
    errs = []
    plain = []
    spans = []
    pos = 0  # 복원 문장 길이(scalar)
    last = 0
    for m in TAG_RE.finditer(marked):
        seg = marked[last:m.start()]
        plain.append(seg)
        pos += len(seg)
        phrase, nums = m.group(1), m.group(2)
        ns = []
        for tok in nums.split(","):
            tok = tok.strip()
            if not tok.isdigit():
                errs.append(f"번호형식:{nums!r}")
                ns = None
                break
            ns.append(int(tok))
        plain.append(phrase)
        if ns is not None:
            spans.append((pos, phrase, ns))
        pos += len(phrase)
        last = m.end()
    tail = marked[last:]
    plain.append(tail)
    text = "".join(plain)
    if any(ch in text for ch in "{}"):
        errs.append("중괄호잔여")
    return text, spans, errs


def validate_verse(ref, marked: str, literal: str, nwords: int, boundary: bool = True,
                   mode: str = "space", excluded=frozenset()):
    """반환: (rows, errors, warnings). rows = [(word_index, phrase, start)].
    mode: "space"(어절 경계, 기존) | "cjk"(문장부호 경계만). excluded: 짝을 지으면 안 되는 단어 번호(1-기반)."""
    errors, warns = [], []
    text, spans, ferr = parse_markup(marked)
    errors += ferr
    if text != literal:
        # 어디서 달라졌는지 짧게
        i = 0
        while i < min(len(text), len(literal)) and text[i] == literal[i]:
            i += 1
        errors.append(f"문장불일치@{i}:{text[i:i+12]!r}≠{literal[i:i+12]!r}")
        return [], errors, warns
    seen = {}
    rows = []
    for start, phrase, ns in spans:
        if not phrase or phrase != phrase.strip():
            errors.append(f"빈구/공백:{phrase!r}")
            continue
        if literal[start:start + len(phrase)] != phrase:  # 구조상 항상 참, 방어용
            errors.append(f"위치불일치:{phrase!r}@{start}")
            continue
        if boundary:
            be = (boundary_error_cjk if mode == "cjk" else boundary_error)(literal, start, phrase)
            if be:
                errors.append(f"어절경계({be}):{phrase!r}@{start}")
        if not ns:
            errors.append(f"번호없음:{phrase!r}")
        for n in ns:
            if n in excluded:
                errors.append(f"제외단어짝:{n}")
                continue
            if not 1 <= n <= nwords:
                errors.append(f"번호범위:{n}/{nwords}")
            elif n in seen:
                errors.append(f"번호중복:{n}")
            else:
                seen[n] = phrase
                rows.append((n - 1, phrase, start))
    if not rows and nwords - len(excluded) >= 3:
        errors.append("대응없음")
    rows.sort()
    return rows, errors, warns


def parse_result_lines(lines):
    """결과 파일 줄 -> {ref: marked}. 형식이 틀린 줄은 bad 목록으로."""
    got, bad, dup = {}, [], []
    for raw in lines:
        line = raw.rstrip("\n").rstrip("\r")
        if not line.strip() or line.startswith("```"):
            continue
        head, sep, rest = line.partition(" ")
        ref = parse_ref(head.strip())
        if not sep or ref is None:
            bad.append(line[:60])
            continue
        if ref in got:
            dup.append(ref)
        got[ref] = rest
    return got, bad, dup


def write_jsonl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


# [2026-11-12 it] 판본 표시 파일(--flags)이 필수인 언어. ko/en/es/pt 는 판본 표시를 도입하기 전에 작업한 언어라 선택 사항으로 둔다.
FLAGS_OPTIONAL_LANGS = frozenset({"ko", "en", "es", "pt"})


def require_flags(lang, flags_path):
    """ko/en/es/pt 가 아닌 언어는 --flags 없이 검사·병합하지 못하게 한다."""
    if lang not in FLAGS_OPTIONAL_LANGS and not flags_path:
        raise SystemExit(f"{lang} 검사·병합에는 --flags(edition_flags_v2.json)가 필요합니다")


def load_excluded(flags_path):
    """[2026-11-11 zh] edition_flags(_v2).json -> {(b,c,v): frozenset(1-기반 제외 단어 번호)}."""
    if not flags_path:
        return {}
    with open(flags_path, encoding="utf-8") as f:
        V = json.load(f)["verses"]
    out = {}
    for ref, rec in V.items():
        ex = rec.get("excluded") or []
        if ex:
            b, c, v = map(int, ref.split(":"))
            out[(b, c, v)] = frozenset(ex)
    return out
