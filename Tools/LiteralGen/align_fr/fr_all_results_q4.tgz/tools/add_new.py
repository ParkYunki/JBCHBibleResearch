"""[fill1] 검사 통과한 결과에서 '새로 추가된 원어 단어'(newidx.json) 행만 WordAlignment에 넣는다.
기존 행은 지우거나 바꾸지 않는다. 같은 (절, word_index) 행이 이미 있으면 건너뛴다.
python3 -I tools/add_new.py --original O --lang L [--literal-db D] --target T --newidx J [--manifest M] [--fail-out F] 결과파일...
"""
import argparse, json, os, sqlite3, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402
import check as C  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--original", required=True); ap.add_argument("--lang", required=True)
ap.add_argument("--literal-db"); ap.add_argument("--target", required=True)
ap.add_argument("--newidx", required=True); ap.add_argument("--manifest"); ap.add_argument("--fail-out")
ap.add_argument("files", nargs="+")
a = ap.parse_args()
tgt = os.path.realpath(a.target)
if tgt.startswith("/mnt/"):
    raise SystemExit("대상이 /mnt/ 아래입니다")
for p in (a.original, a.literal_db):
    if p and os.path.realpath(p) == tgt:
        raise SystemExit("대상이 원본과 같은 파일입니다")
newidx = {tuple(map(int, k.split(":"))): set(v) for k, v in json.load(open(a.newidx)).items()}
src = L.Source(a.original, a.lang, a.literal_db)
lits, words = src.literals(), src.words()
ok, fails, st = C.check_files(a.files, lits, words, C.load_manifest(a.manifest), True)
print(f"검사: 합격 {len(ok)}절 / 불합격 {len(fails)}절 / 형식오류 줄 {st['bad_lines']}")
if a.fail_out:
    with open(a.fail_out, "w", encoding="utf-8") as f:
        for r in sorted(fails):
            f.write(f"{L.ref_str(*r)}\t{'; '.join(fails[r])}\n")
con = sqlite3.connect(tgt)
added = skipped = 0
with con:
    for key, rows in sorted(ok.items()):
        want = newidx.get(key)
        if not want:
            continue
        have = {r[0] for r in con.execute(
            "SELECT word_index FROM WordAlignment WHERE book_id=? AND chapter=? AND verse=?", key)}
        for wi, ph, s in rows:
            if wi in want:
                if wi in have:
                    skipped += 1
                    continue
                con.execute("INSERT INTO WordAlignment VALUES(?,?,?,?,?,?)", (*key, wi, ph, s))
                added += 1
print(f"추가: {added}행 / 이미 있어 건너뜀 {skipped}행")
bad = total = 0
for b, c, v, wi, ph, s in con.execute("SELECT * FROM WordAlignment"):
    total += 1
    t = lits.get((b, c, v)); nw = len(words.get((b, c, v), []))
    if t is None or not (0 <= wi < nw) or not ph or s < 0 or t[s:s + len(ph)] != ph:
        bad += 1
ic = con.execute("PRAGMA integrity_check").fetchone()[0]
print(f"재검증: 전체 {total}행 / 표시규칙 위반 {bad} / integrity_check={ic}")
con.close()
if bad or ic != "ok":
    sys.exit(2)
