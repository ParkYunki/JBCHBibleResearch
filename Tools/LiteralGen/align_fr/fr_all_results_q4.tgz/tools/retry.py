"""재시도 목록 추출: manifest 대상 절 중 결과가 없거나 검사 불합격인 절.

python3 -I tools/retry.py --original src/OriginalText.sqlite --manifest packets/ko/manifest.jsonl \
    --out retry/retry1.txt 결과파일...
그다음: python3 -I tools/make_packets.py --original ... --refs retry/retry1.txt --out packets/retry1
(--size 를 줄이면 긴 절 실패가 줄어든다. 예: --size 20)
"""
import argparse
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402
import check as C  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True)
    ap.add_argument("--lang", default="ko")
    ap.add_argument("--literal-db")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--no-boundary", action="store_true")
    ap.add_argument("files", nargs="*")
    a = ap.parse_args()
    src = L.Source(a.original, a.lang, a.literal_db)
    lits, words = src.literals(), src.words()
    byref, bypkt = C.load_manifest(a.manifest)
    ok, fails, _ = C.check_files(a.files, lits, words, (byref, bypkt), not a.no_boundary) if a.files else ({}, {}, {})
    todo = {}
    for r in byref:
        if r in ok:
            continue
        todo[r] = "; ".join(fails.get(r, ["결과없음"]))
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        for r in sorted(todo):
            f.write(f"{L.ref_str(*r)}\t{todo[r]}\n")
    kinds = collections.Counter(why.split(";")[0].split(":")[0].split("@")[0].split("(")[0] for why in todo.values())
    print(f"대상 {len(byref)}절 / 합격 {len(ok)} / 재시도 {len(todo)} → {a.out}")
    for k, v in kinds.most_common():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
