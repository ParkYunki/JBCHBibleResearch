# [2026-11-17 fr] 프랑스어 결과 표본: 묶음 범위 A..B 에서 N절을 뽑아 {구간=원어 영어 문맥번역}으로 보여 준다.
import sys,glob,re,random,sqlite3
A,B,N,S=map(int,sys.argv[1:5])
o=sqlite3.connect('src/OriginalText_cur.sqlite')
lines=[l.rstrip('\n') for n in range(A,B+1) for l in open('results/fr_all/p%04d.txt'%n,encoding='utf-8') if l.strip()]
random.seed(S)
for l in random.sample(lines,N):
    ref,m=l.split(' ',1); b,c,v=map(int,ref.split(':'))
    ws=[r[0] for r in o.execute("select translation_en from original_words where book_id=? and chapter=? and verse=? order by word_order,rowid",(b,c,v))]
    out=re.sub(r"\{([^{}|]*)\|([0-9,]+)\}",lambda mm:'{'+mm.group(1)+'='+'+'.join(ws[int(n)-1] if int(n)<=len(ws) else '?' for n in mm.group(2).split(','))+'}',m)
    print(ref,out[:420])
