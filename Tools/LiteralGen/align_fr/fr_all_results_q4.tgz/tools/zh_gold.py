"""[zh] 시범 확정본: 1차 결과(합격분) 위에 재실행 결과(73절)를 덮고, ChatGPT 판정 중 맞는 구간이 그 절 직역에 한 번만 나오는 것을 Python으로 반영한다.
반영 후 다시 검사(문장부호 경계·제외 단어)를 통과한 것만 남긴다. 출력: zh_gold.jsonl {ref, rows:[[word_index, phrase, start]]}"""
import sys, glob, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L, check as C
src = L.Source('src/OriginalText_cur.sqlite', 'zh', 'src/Literal_zh.sqlite'); lits, words = src.literals(), src.words()
ex = L.load_excluded('src/edition_flags_v2.json')
a, _, _ = C.check_files(sorted(glob.glob('results/zh_pilot/p*.txt')), lits, words, C.load_manifest('packets/zh_pilot/manifest.jsonl'), True, 0, 'cjk', ex)
b, _, _ = C.check_files(sorted(glob.glob('results/zh_rerun/p*.txt')), lits, words, C.load_manifest('packets/zh_rerun/manifest.jsonl'), True, 0, 'cjk', ex)
gold = {r: {w: (ph, s) for w, ph, s in rows} for r, rows in a.items()}
for r, rows in b.items():
    gold[r] = {w: (ph, s) for w, ph, s in rows}
applied = skipped = 0
for fn in sorted(glob.glob('zh_review/*.tsv')):
    for l in open(fn, encoding='utf-8'):
        p = l.rstrip('\n').split('\t')
        if len(p) < 5 or p[0] == '요약': continue
        r = L.parse_ref(p[0]); w = int(p[1]) - 1; want = p[3]
        if r not in gold: skipped += 1; continue
        if want == '—':
            gold[r].pop(w, None); applied += 1; continue
        t = lits[r]
        if t.count(want) != 1 or L.boundary_error_cjk(t, t.find(want), want) or (w + 1) in ex.get(r, ()):
            skipped += 1; continue
        gold[r][w] = (want, t.find(want)); applied += 1
with open('zh_gold.jsonl', 'w', encoding='utf-8') as f:
    for r in sorted(gold):
        rows = sorted([w, ph, s] for w, (ph, s) in gold[r].items())
        for w, ph, s in rows:
            assert lits[r][s:s + len(ph)] == ph
        f.write(json.dumps({"ref": L.ref_str(*r), "rows": rows}, ensure_ascii=False) + "\n")
print('verses', len(gold), 'review applied', applied, 'skipped(ambiguous)', skipped)
