"""결과(마크업) 검사.

python3 -I tools/check.py --original src/OriginalText.sqlite [--manifest packets/ko/manifest.jsonl] 결과파일...
  결과 파일 이름이 p0001*.txt 처럼 패킷 이름으로 시작하면 manifest의 그 패킷 절 목록과 대조한다(누락 검출).
  --fail-out fails.tsv : 불합격 절 목록(ref<TAB>사유)
  --strict-coverage 0.0 : 절별 정렬 단어 비율이 이 값 미만이면 불합격(기본 0 = 사용 안 함)

검사 항목
 - 형식: 줄 = `b:c:v 마크업`, 중괄호 잔여, 번호 형식
 - 문장 복원: 표기를 지운 문장 == 현재 DB 직역(글자 단위)
 - phrase가 직역의 start 위치 부분 문자열(구조상 보장, 재확인)
 - 어절 경계(ko 기본, --no-boundary로 끔)
 - 번호 범위(1..단어 수), 번호 중복(한 단어는 한 구간만)
 - 겹침: 마크업 구조상 서로 다른 구간은 겹칠 수 없고, 같은 구간 공유만 가능
 - 단어 수 일치/데이터 변경: manifest의 nwords·지문(wfp, tfp)과 현재 DB 비교
 - 누락·중복 절, 대상 밖 절
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402

PKT_RE = re.compile(r"^(p\d{4})")


def load_manifest(path):
    if not path:
        return {}, {}
    byref, bypkt = {}, {}
    for m in L.read_jsonl(path):
        r = L.parse_ref(m["ref"])
        byref[r] = m
        bypkt.setdefault(m["packet"], []).append(r)
    return byref, bypkt


def check_files(paths, lits, words, manifest=None, boundary=True, min_cov=0.0, mode="space", excluded=None):
    """반환: (ok{ref: rows}, fails{ref: [사유]}, stats dict)"""
    byref, bypkt = manifest or ({}, {})
    ok, fails = {}, {}
    st = dict(lines=0, verses=0, words=0, aligned=0, bad_lines=0)

    def fail(r, why):
        fails.setdefault(r, []).append(why)

    for p in paths:
        with open(p, encoding="utf-8") as f:
            got, bad, dup = L.parse_result_lines(f)
        st["bad_lines"] += len(bad)
        for b in bad:
            print(f"  [{os.path.basename(p)}] 형식오류 줄: {b!r}", file=sys.stderr)
        for r in dup:
            fail(r, "절중복출력")
        m = PKT_RE.match(os.path.basename(p))
        expected = bypkt.get(m.group(1)) if (m and bypkt) else None
        if expected is not None:
            for r in expected:
                if r not in got:
                    fail(r, "누락")
            exp = set(expected)
            for r in got:
                if r not in exp:
                    fail(r, "대상밖절")
        for r, marked in got.items():
            st["verses"] += 1
            if r not in lits or r not in words:
                fail(r, "DB에없는절")
                continue
            ws = words[r]
            if r in byref:
                mf = byref[r]
                if mf["nwords"] != len(ws):
                    fail(r, f"단어수불일치:{mf['nwords']}≠{len(ws)}")
                if mf["wfp"] != L.words_fingerprint(ws):
                    fail(r, "원어목록변경")
                if mf["tfp"] != L.text_fingerprint(lits[r]):
                    fail(r, "직역변경")
            rows, errs, _ = L.validate_verse(r, marked, lits[r], len(ws), boundary,
                                             mode, (excluded or {}).get(r, frozenset()))
            for e in errs:
                fail(r, e)
            cov = len(rows) / len(ws) if ws else 1.0
            if min_cov and cov < min_cov:
                fail(r, f"정렬비율낮음:{cov:.2f}")
            if r not in fails:
                ok[r] = rows
                st["words"] += len(ws)
                st["aligned"] += len(rows)
    for r in list(ok):
        if r in fails:
            del ok[r]
    return ok, fails, st


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True)
    ap.add_argument("--lang", default="ko")
    ap.add_argument("--literal-db")
    ap.add_argument("--manifest")
    ap.add_argument("--fail-out")
    ap.add_argument("--no-boundary", action="store_true")
    ap.add_argument("--strict-coverage", type=float, default=0.0)
    ap.add_argument("--flags", help="[zh] edition_flags_v2.json — 제외 단어에 짝이 있으면 불합격")
    ap.add_argument("files", nargs="+")
    a = ap.parse_args()
    src = L.Source(a.original, a.lang, a.literal_db)
    lits, words = src.literals(), src.words()
    mode = "cjk" if a.lang == "zh" else "space"
    L.require_flags(a.lang, a.flags)
    ok, fails, st = check_files(a.files, lits, words, load_manifest(a.manifest),
                                not a.no_boundary, a.strict_coverage, mode, L.load_excluded(a.flags))
    cov = st["aligned"] / st["words"] * 100 if st["words"] else 0
    print(f"합격 {len(ok)}절 / 불합격 {len(fails)}절 / 형식오류 줄 {st['bad_lines']} / "
          f"합격 절의 단어 정렬비율 {cov:.1f}% ({st['aligned']}/{st['words']})")
    for r in sorted(fails):
        print(f"  불합격 {L.ref_str(*r)}: {'; '.join(fails[r])}")
    if a.fail_out:
        with open(a.fail_out, "w", encoding="utf-8") as f:
            for r in sorted(fails):
                f.write(f"{L.ref_str(*r)}\t{'; '.join(fails[r])}\n")
    sys.exit(1 if fails or st["bad_lines"] else 0)


if __name__ == "__main__":
    main()
