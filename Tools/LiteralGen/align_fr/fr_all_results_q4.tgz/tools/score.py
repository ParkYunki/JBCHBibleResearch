"""모델 결과를 정답과 비교 채점.

python3 -I tools/score.py --original src/OriginalText.sqlite --gold gold/compare_gold.txt \
    --refs compare/refs.txt [--errors-out errors.tsv] 결과파일...

단위: 원어 단어 1개. 정답·예측 각각 (phrase, start) 또는 '없음'.
- 정확: 둘 다 없음, 또는 phrase·start 모두 같음
- 오류 유형
    누락      정답 있음 / 예측 없음
    과잉      정답 없음 / 예측 있음
    위치오류  둘 다 있으나 겹치지 않음(다른 자리 — 같은 낱말의 다른 출현 포함)
    범위넓음  겹치고 예측이 정답을 포함(더 넓음)
    범위좁음  겹치고 정답이 예측을 포함(더 좁음)
    범위어긋남 겹치지만 포함 관계 아님
    절불합격  그 절이 형식 검사(check.py와 같은 규칙)에서 불합격 → 그 절 단어 전부 오류
    절누락    결과에 절이 없음 → 그 절 단어 전부 오류
- 느슨한 정확도: 정확 + 범위넓음/좁음/어긋남(겹치면 맞음으로 침)
분류: 품사(형태 코드), 유형(refs.txt 2열의 '+' 앞), 구약/신약
"""
import argparse
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402

GREEK_POS = {"N": "명사", "V": "동사", "A": "형용사", "T": "관사", "CONJ": "접속사", "COND": "접속사",
             "PREP": "전치사", "ADV": "부사", "INJ": "기타"}
HEB_T = {"o": "목적격표지", "d": "관사", "n": "부정어"}


def pos_class(book: int, morph: str) -> str:
    if book >= 40:
        head = morph.split(" + ")[0]
        if head.startswith("PRT-N"):
            return "부정어"
        p = head.split("-")[0]
        if p in GREEK_POS:
            return GREEK_POS[p]
        if p == "PRT":
            return "불변사"
        return "대명사"  # P R D I X F S K C Q
    segs = morph.split("/")
    segs[0] = segs[0][1:]  # 언어 표지(H/A) 제거
    letters = [s[:1] for s in segs if s]
    for s in segs:
        if s[:1] in ("N", "V", "A", "P", "D"):
            return {"N": "명사", "V": "동사", "A": "형용사", "P": "대명사", "D": "부사"}[s[:1]]
    for s in segs:
        if s[:1] == "T":
            return HEB_T.get(s[1:2], "불변사")
    if "R" in letters:
        return "전치사"
    if "C" in letters:
        return "접속사"
    return "기타"


def load_markup(path):
    with open(path, encoding="utf-8") as f:
        got, bad, _ = L.parse_result_lines(f)
    return got, bad


def word_map(rows):
    return {wi: (phrase, start) for wi, phrase, start in rows}


def classify(g, p):
    if g is None and p is None:
        return "정확"
    if g is None:
        return "과잉"
    if p is None:
        return "누락"
    if g == p:
        return "정확"
    gs, ge = g[1], g[1] + len(g[0])
    ps, pe = p[1], p[1] + len(p[0])
    if pe <= gs or ge <= ps:
        return "위치오류"
    if ps <= gs and pe >= ge:
        return "범위넓음"
    if gs <= ps and ge >= pe:
        return "범위좁음"
    return "범위어긋남"


LENIENT_OK = {"정확", "범위넓음", "범위좁음", "범위어긋남"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True)
    ap.add_argument("--gold", required=True)
    ap.add_argument("--refs", help="refs.txt (유형 열)")
    ap.add_argument("--errors-out")
    ap.add_argument("--no-boundary", action="store_true")
    ap.add_argument("preds", nargs="+")
    a = ap.parse_args()

    src = L.Source(a.original)
    lits, words = src.literals(), src.words()
    gold_mk, gbad = load_markup(a.gold)
    if gbad:
        raise SystemExit(f"정답 파일 형식 오류: {gbad[:3]}")
    cats = {}
    if a.refs:
        for line in open(a.refs, encoding="utf-8"):
            t = line.rstrip("\n").split("\t")
            if t and t[0] and not t[0].startswith("#"):
                cats[L.parse_ref(t[0])] = t[1].split("+")[0] if len(t) > 1 else "-"
    pred_mk = {}
    pbad = 0
    for p in a.preds:
        got, bad = load_markup(p)
        pbad += len(bad)
        pred_mk.update(got)

    tot = collections.Counter()
    by = collections.defaultdict(collections.Counter)  # (축, 값) -> Counter(결과)
    errors = []
    verse_fail = []
    for r, gm in gold_mk.items():
        ws = words[r]
        grows, gerr, _ = L.validate_verse(r, gm, lits[r], len(ws), not a.no_boundary)
        if gerr:
            raise SystemExit(f"정답 {L.ref_str(*r)} 자체가 불합격: {gerr}")
        gmap = word_map(grows)
        if r not in pred_mk:
            pmap, vstate = {}, "절누락"
        else:
            prows, perr, _ = L.validate_verse(r, pred_mk[r], lits[r], len(ws), not a.no_boundary)
            if perr:
                pmap, vstate = {}, "절불합격"
                verse_fail.append((r, perr))
            else:
                pmap, vstate = word_map(prows), None
        for i, w in enumerate(ws):
            g, p = gmap.get(i), pmap.get(i)
            res = vstate or classify(g, p)
            keys = [("품사", pos_class(r[0], w["morph"])), ("성경", "신약" if r[0] >= 40 else "구약"),
                    ("유형", cats.get(r, "-")), ("정답", "대응있음" if g else "대응없음")]
            tot[res] += 1
            for k in keys:
                by[k][res] += 1
            if res != "정확":
                errors.append((L.ref_str(*r), i + 1, w["tr"] or w["gloss"], res,
                               g[0] if g else "", g[1] if g else "", p[0] if p else "", p[1] if p else ""))

    n = sum(tot.values())

    def pct(c):
        s = sum(c.values())
        return (c["정확"] / s * 100 if s else 0, sum(c[k] for k in LENIENT_OK) / s * 100 if s else 0, s)

    ex, le, _ = pct(tot)
    print(f"채점 {len(gold_mk)}절 / 단어 {n} / 결과 형식오류 줄 {pbad} / 절불합격 {len(verse_fail)} / "
          f"절누락 {sum(1 for r in gold_mk if r not in pred_mk)}")
    print(f"정확도(엄격) {ex:.1f}%   느슨(겹치면 맞음) {le:.1f}%")
    print("오류 유형: " + ", ".join(f"{k} {v}" for k, v in tot.most_common() if k != "정확"))
    for axis in ("정답", "성경", "품사", "유형"):
        print(f"\n[{axis}별]  값 | 단어 | 엄격% | 느슨% | 주요 오류")
        rows = sorted(((k[1], c) for k, c in by.items() if k[0] == axis), key=lambda x: -sum(x[1].values()))
        for val, c in rows:
            e, l2, s = pct(c)
            top = ", ".join(f"{k}{v}" for k, v in c.most_common() if k != "정확")[:60]
            print(f"  {val} | {s} | {e:.1f} | {l2:.1f} | {top}")
    if verse_fail:
        print("\n[절불합격]")
        for r, e in verse_fail[:30]:
            print(f"  {L.ref_str(*r)}: {'; '.join(e)[:120]}")
    if a.errors_out:
        with open(a.errors_out, "w", encoding="utf-8") as f:
            f.write("ref\tn\t영어\t유형\t정답구\t정답start\t예측구\t예측start\n")
            for e in errors:
                f.write("\t".join(str(x) for x in e) + "\n")
        print(f"\n오류 {len(errors)}건 → {a.errors_out}")


if __name__ == "__main__":
    main()
