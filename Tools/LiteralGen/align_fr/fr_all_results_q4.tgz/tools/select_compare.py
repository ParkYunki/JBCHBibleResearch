"""정확도 비교용 200절 선정(결정적, seed 고정). 요 1장·창 1장(시범)은 제외.

python3 -I tools/select_compare.py --original src/OriginalText.sqlite --out compare/refs.txt
출력 줄: `b:c:v<TAB>유형<TAB>단어수`
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L  # noqa: E402

NAME_LISTS = {(1, 5), (1, 10), (1, 11), (1, 36), (13, 1), (13, 2), (13, 3), (13, 4), (13, 5), (13, 6),
              (13, 7), (13, 8), (13, 9), (15, 2), (16, 7), (40, 1), (42, 3)}
LAW = {3, 5}
LAW_EX = range(20, 32)  # 출 20-31
QUOTA = [  # (유형, 수)
    ("오경서사", 20), ("율법", 15), ("역사서", 25), ("이름목록", 15), ("시가서", 30),
    ("대선지서", 20), ("소선지서", 10), ("복음서행전", 30), ("바울서신", 20), ("공동서신계시록", 10),
    ("긴절", 5),
]
FORCED = {  # 반드시 넣을 절(유형은 자동 분류, 긴절은 아래 규칙)
    (5, 30, 16): "word_order중복", (7, 16, 14): "word_order중복", (10, 23, 33): "word_order중복",
    (12, 25, 3): "word_order중복", (43, 21, 7): "비NFC",
}


def category(b, c, v, nwords, long_cut):
    if nwords >= long_cut:
        return "긴절"
    if (b, c) in NAME_LISTS:
        return "이름목록"
    if b in LAW or (b == 2 and c in LAW_EX):
        return "율법"
    if b in (1, 2, 4):
        return "오경서사"
    if 6 <= b <= 17:
        return "역사서"
    if 18 <= b <= 22:
        return "시가서"
    if 23 <= b <= 27:
        return "대선지서"
    if 28 <= b <= 39:
        return "소선지서"
    if 40 <= b <= 44:
        return "복음서행전"
    if 45 <= b <= 58:  # 히브리서 포함
        return "바울서신"
    return "공동서신계시록"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--original", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=20261102)
    a = ap.parse_args()
    src = L.Source(a.original)
    lits, words = src.literals(), src.words()
    refs = sorted(set(lits) & set(words))
    refs = [r for r in refs if not ((r[0], r[1]) in {(43, 1), (1, 1)})]
    lens = sorted(len(words[r]) for r in refs)
    long_cut = lens[int(len(lens) * 0.99)]
    bycat = {}
    for r in refs:
        bycat.setdefault(category(*r, len(words[r]), long_cut), []).append(r)
    rnd = random.Random(a.seed)
    chosen = {}
    for r, why in FORCED.items():
        chosen[r] = category(*r, len(words[r]), long_cut) + "+" + why
    # 직역에 대괄호가 있는 절 2개 강제
    brk = [r for r in refs if "[" in lits[r] and r not in chosen and len(words[r]) < long_cut]
    for r in rnd.sample(brk, 2):
        chosen[r] = category(*r, len(words[r]), long_cut) + "+대괄호"
    for cat, q in QUOTA:
        have = sum(1 for v in chosen.values() if v.split("+")[0] == cat)
        pool = [r for r in bycat[cat] if r not in chosen]
        for r in rnd.sample(pool, max(0, q - have)):
            chosen[r] = cat
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(f"# seed={a.seed} long_cut(단어수>=)={long_cut}\n")
        for r in sorted(chosen):
            f.write(f"{L.ref_str(*r)}\t{chosen[r]}\t{len(words[r])}\n")
    tot = sum(len(words[r]) for r in chosen)
    print(f"{len(chosen)}절, 단어 {tot}, 긴절 기준 {long_cut}")


if __name__ == "__main__":
    main()
