#!/bin/bash
# [2026-11-12 it] 이탈리아어 50절 예비시험: 조건 하나의 결과를 검사한다(DB에 병합하지 않는다).
# 사용: it_pilot/check_cond.sh H0      (작업 폴더 /home/claude/integ/align 에서)
# 입력 묶음 : it_pilot/packets/<조건>/p0001.txt ~ p0005.txt, manifest.jsonl
# 결과 파일 : it_pilot/results/<조건>/p0001.txt ~ p0005.txt   (작업이 씀)
# 검사 산출 : it_pilot/results/<조건>_check.txt  구조 검사 요약과 불합격 사유
#             it_pilot/results/<조건>_fails.tsv  불합격 절
#             it_pilot/results/<조건>_rows.tsv   합격 절의 행(절, 단어번호, 구간, 시작)
#             it_pilot/results/<조건>_warn.tsv   경고 목록
set -u
cd /home/claude/integ/align
C=$1; P=it_pilot/packets/$C; R=it_pilot/results/$C
O="--original src/OriginalText_cur.sqlite --lang it --literal-db src_it/Literal_it.sqlite --manifest $P/manifest.jsonl --flags src/edition_flags_v2.json"
# 1) 파일 누락: 묶음마다 결과 파일이 있어야 한다
miss=0
for f in $P/p*.txt; do b=$(basename $f); [ -s "$R/$b" ] || { echo "결과 파일 없음: $R/$b"; miss=1; }; done
extra=$(ls $R 2>/dev/null | grep -v -x -f <(ls $P | grep '^p') | tr '\n' ' '); [ -z "$extra" ] || echo "예상 밖 파일: $extra"
[ $miss = 0 ] || { echo "파일 누락으로 중단"; exit 3; }
# 2) 구조 검사(절 누락·중복·대상 밖 절·지문·문장 일치·경계·번호·제외 단어)
python3 -I tools/check.py $O --fail-out ${R}_fails.tsv $R/p*.txt > ${R}_check.txt 2>&1; rc=$?
grep '^합격' ${R}_check.txt
# 3) 절 누락 재확인(목록 파일 기준, 검사기와 독립)
python3 -I - "$P/manifest.jsonl" $R/p*.txt <<'PY'
import sys, json
want = [json.loads(l)["ref"] for l in open(sys.argv[1], encoding="utf-8")]
got = [l.split(" ", 1)[0] for p in sys.argv[2:] for l in open(p, encoding="utf-8") if l.strip()]
print("요청 절", len(want), "/ 결과 줄", len(got), "/ 누락", [r for r in want if r not in got], "/ 중복", sorted({r for r in got if got.count(r) > 1}), "/ 대상 밖", [r for r in got if r not in want])
PY
# 4) 합격 절의 행 내보내기
python3 -I - $O --out ${R}_rows.tsv $R/p*.txt <<'PY'
import sys, argparse
sys.path.insert(0, "tools")
import alignlib as L, check as C
ap = argparse.ArgumentParser()
for k in ("--original", "--lang", "--literal-db", "--manifest", "--flags", "--out"): ap.add_argument(k)
ap.add_argument("files", nargs="+"); a = ap.parse_args()
L.require_flags(a.lang, a.flags)
src = L.Source(a.original, a.lang, a.literal_db); lits, words = src.literals(), src.words()
ok, fails, st = C.check_files(a.files, lits, words, C.load_manifest(a.manifest), True, 0.0, "space", L.load_excluded(a.flags))
with open(a.out, "w", encoding="utf-8") as f:
    f.write("절\t단어번호\t구간\t시작\n")
    for r in sorted(ok):
        for wi, ph, s in ok[r]: f.write(f"{L.ref_str(*r)}\t{wi+1}\t{ph}\t{s}\n")
print("행 내보내기:", sum(len(v) for v in ok.values()), "행 /", len(ok), "절")
PY
# 5) 경고 목록
python3 -I tools/warn.py $O --hint ES=src_it/Literal_es.sqlite --hint EN=src_it/Literal_en.sqlite --hold it_pilot/hold_refs.txt --out ${R}_warn.tsv $R/p*.txt
exit $rc
