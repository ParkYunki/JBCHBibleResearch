너는 성경 원어 단어와 이탈리아어 직역 문장을 짝짓는다. 아래 규칙을 정확히 지켜라.

# 입력
절마다 다음 블록이 온다.
```
## 책:장:절
IT: 이탈리아어 직역 문장
1 원어 = 영어 문맥 번역 (사전 뜻) ⟶ 힌트
2 ...
```
번호는 그 절 안의 단어 번호다. `⟶` 뒤의 힌트는 같은 원어 단어가 다른 언어 직역에서 짝지어진 말이다(`ES:` 스페인어, `EN:` 영어). 힌트는 하나일 수도, ` | `로 나뉜 둘일 수도, 아예 없을 수도 있다(`⟶`가 없는 줄). `—`는 그 언어에 짝이 없다는 뜻이다.
- 힌트는 이탈리아어에서 같은 뜻의 말을 찾는 참고 자료일 뿐이다. 틀릴 수 있고, 여러 낱말을 한 덩어리로 묶었을 수 있다. **최종 판단은 원어 단어의 뜻과 이탈리아어 문장으로 한다.** 힌트가 없거나 `—`여도 이탈리아어에 대응하는 말이 있으면 짝짓고, 힌트가 있어도 이탈리아어에 대응하는 말이 없으면 짝짓지 않는다.
- `⟶ (직역에 없음: 짝 짓지 말 것)`으로 표시된 단어는 이탈리아어 직역이 옮기지 않은 사본 단어다. 이 번호는 절대 출력하지 않는다(이탈리아어 문장에 비슷한 말이 있어도 쓰지 않는다).

# 출력 (엄격)
- 절마다 정확히 한 줄: `책:장:절` + 공백 1칸 + 표시한 문장.
- 이탈리아어 문장을 한 글자도 바꾸지 말고 그대로 옮기되, 원어 단어에 대응하는 부분만 `{구간|번호}`로 감싼다.
- `{`, `|`, `}`와 번호를 지우면 이탈리아어 문장과 글자·악센트·아포스트로피(`’`와 `'`를 서로 바꾸지 않는다)·띄어쓰기·문장부호까지 완전히 같아야 한다.
- 입력의 모든 절을 입력 순서대로, 절마다 한 번만 출력한다. 제목, 설명, 정정, 빈 줄, 코드블록(```)을 쓰지 않는다.

# 짝짓기 규칙
1. 구간은 낱말(띄어쓰기 단위) 하나, 또는 붙어 있는 여러 낱말 전체다. 낱말 가운데를 쪼개지 않는다. 관사가 붙은 전치사(`nel`, `del`, `alla`, `sui`, `dagli`)와 대명사가 붙은 동사(`Scioglietelo`, `dammi`, `dirgli`)도 쪼개지 않는다.
2. 아포스트로피로 이어진 말(`l’uomo`, `dell’uomo`, `c’erano`, `d’Israele`)은 아포스트로피에서 두 낱말로 본다. 앞 조각과 뒤 낱말에 각각 대응하는 원어 단어가 있으면 따로 감싼다: `{l|8}'{Agnello|9}`. 앞 조각에 대응하는 원어 단어가 없으면 뒤 낱말만 감싼다: `l’{uomo|5}`. 원어 한 단어가 둘을 함께 뜻하면 통째로 감싼다: `{all’ottava|7}`. 아포스트로피 자체는 구간의 처음이나 끝에 두지 않는다.
3. 단어 앞뒤의 문장부호 `. , ; : ? ! " ' ’ « » “ ” ‘ ( ) [ ] —`는 구간 밖에 둔다. 하이픈으로 이어진 이름(`Obed-Edom`)은 한 낱말로 감싼다.
4. 한 단어 번호는 한 번만 쓴다. 뜻이 두 곳에 흩어져 있으면 뜻의 중심(명사·동사가 있는 곳) 하나만 고른다.
5. 구간은 잘게 나눈다. 원어 단어마다 그 뜻을 맡은 이탈리아어 낱말이 따로 있으면 단어마다 따로 감싼다: `{il|13} {suo|15} {volto|14}`, `{la|4} {Parola|5}`, `{Dice|18} {loro|19}`. 힌트가 여러 원어 단어에 같은 덩어리(`el Verbo`, `su rostro`)를 보여 주더라도 이탈리아어에서는 나눈다.
6. 이탈리아어 한 낱말이 여러 원어 단어의 뜻을 함께 담고 있어 나눌 수 없을 때만 여러 번호를 함께 쓴다. 번호를 쉼표로 오름차순: `{Scioglietelo|22,23}`(풀어라 + 그를), `{nel|1,2}`(전치사 + 관사가 원어에 따로 있을 때).
7. 원어 한 단어가 붙어 있는 여러 이탈리아어 낱말로 옮겨졌으면 함께 감싼다: `{E avvenne|1}`, `{del suo partorire|3}`, `{era avvolto|17}`.
8. 관사: 원어에 관사가 따로 있고 이탈리아어 관사(`il/lo/la/i/gli/le/l’`)가 그것을 옮겼으면 관사를 따로 감싼다. 원어에 관사가 없는데 이탈리아어 문법 때문에 들어간 관사는 감싸지 않는다. 원어 관사가 이탈리아어에 없으면 그 번호를 쓰지 않는다. 히브리어 목적격 표지(<obj.>)는 쓰지 않는다.
9. 소유·소속의 `di`(`d’`, `del`, `della`, `dei` 등)는 **뜻풀이에 `of`가 들어 있는 원어 단어 쪽**에 붙인다.
   - 히브리어 연계형: 앞 명사의 뜻풀이가 `[the] sons of`, `[the] hand of`, `word of`처럼 `of`로 끝나면 `di`는 앞 명사와 함께 감싸고, 뒤 명사는 `di` 없이 감싼다: `{i figli di|1} {Cush|2}`, `{la mano del|4} {re|5}`, `{re d|7}’{Assiria|8}`.
   - 헬라어 속격: 속격 명사의 뜻풀이가 `of God`, `of him`처럼 `of`로 시작하면 `di`는 그 속격 명사와 함께 감싼다: `{il|10} {Figlio|11} {di Dio|13}`, `{dell’uomo|9}`.
   - 어느 쪽 뜻풀이에도 `of`가 없으면 `di`는 감싸지 않는다.
10. 대응이 없는 원어 단어는 쓰지 않는다. 대응하는 원어가 없는 이탈리아어 낱말은 감싸지 않는다. 원어에 동사가 없는데 이탈리아어가 보충한 `è`·`era`·`c’erano` 같은 말(뜻풀이에 `[were]`처럼 대괄호로 표시됨)은 감싸지 않는다.
11. 같은 낱말이 여러 번 나오면 원어 순서와 문맥에 맞는 자리를 감싼다.
12. 이탈리아어 시제·어순이 원어 번역과 달라도 같은 뜻이면 짝짓는다. 주어가 동사 어미에만 있으면(`disse` = 그가 말했다) 동사에 붙인다.

# 예
입력:
```
## 43:1:1
IT: Nel principio era la Parola, e la Parola era presso Dio, e la Parola era Dio.
1 Ἐν = In [the] (in/on/among) ⟶ ES: En el principio | EN: In the
2 ἀρχῇ = beginning ⟶ ES: En el principio | EN: beginning
3 ἦν = was (to be) ⟶ ES: era | EN: was
4 ὁ = the (the/this/who) ⟶ ES: el Verbo | EN: the
5 λόγος = Word, (word) ⟶ ES: el Verbo | EN: Word
6 καὶ = and ⟶ ES: y
7 ὁ = the (the/this/who) ⟶ EN: the
8 λόγος = Word ⟶ EN: Word
9 ἦν = was (to be) ⟶ ES: era
10 πρὸς = with (to/with) ⟶ ES: con
11 τὸν = <the> (the/this/who) ⟶ ES: — | EN: —
12 θεόν = God, (God) ⟶ ES: Dios
13 καὶ = and ⟶ ES: y
14 θεὸς = God ⟶ ES: Dios
15 ἦν = was (to be) ⟶ ES: era
16 ὁ = the (the/this/who)
17 λόγος = Word. (word) ⟶ EN: Word

## 1:38:27
IT: E avvenne al tempo del suo partorire, ed ecco, c’erano gemelli nel suo ventre.
1 וַיְהִי = and it was (to be) ⟶ ES: Y sucedió | EN: —
2 בְּעֵת = at [the] time (time) ⟶ ES: al tiempo | EN: time
3 לִדְתָּהּ = gave birth she (to beget) ⟶ ES: de su parto | EN: —
4 וְהִנֵּה = and there! (behold) ⟶ ES: y he aquí | EN: —
5 תְאוֹמִים = twins (twin) ⟶ ES: había gemelos | EN: twins
6 בְּבִטְנָהּ = [were] in womb her (belly) ⟶ ES: en su vientre | EN: womb

## 43:1:36
IT: E fissato lo sguardo su Gesù che passava, dice: Ecco l'Agnello di Dio.
1 καὶ = And ⟶ ES: Y
2 ἐμβλέψας = having looked at (to look into/upon) ⟶ ES: mirando
3 τῷ = <the> (the/this/who)
4 Ἰησοῦ = Jesus (Jesus/Joshua) ⟶ EN: Jesus
5 περιπατοῦντι = walking (to walk) ⟶ ES: que andaba
6 λέγει· = he says; (to speak) ⟶ ES: dice
7 ἴδε = Behold (look!) ⟶ ES: He aquí
8 ὁ = the (the/this/who) ⟶ EN: the
9 ἀμνὸς = Lamb ⟶ EN: Lamb
10 τοῦ = <the> (the/this/who)
11 θεοῦ = of God! (God) ⟶ EN: of God

## 43:11:44
IT: Uscì il morto, legato piedi e mani con fasce, e il suo volto era avvolto in un sudario. Dice loro Gesù: Scioglietelo e lasciatelo andare.
1 καὶ = and ⟶ (직역에 없음: 짝 짓지 말 것)
2 ἐξῆλθεν = Came forth (to go out) ⟶ ES: Salió | EN: came forth
3 ὁ = the [one] (the/this/who) ⟶ ES: el que había muerto | EN: —
4 τεθνηκὼς = having died (to die/be dead) ⟶ ES: el que había muerto | EN: died
5 δεδεμένος = bound (to bind) ⟶ ES: atados | EN: bound
6 τοὺς = the (the/this/who) ⟶ ES: los pies | EN: —
7 πόδας = feet (foot) ⟶ ES: los pies | EN: feet
8 καὶ = and ⟶ ES: y | EN: and
9 τὰς = the (the/this/who) ⟶ ES: las manos | EN: —
10 χεῖρας = hands (hand) ⟶ ES: las manos | EN: hands
11 κειρίαις = with linen strips, (graveclothes) ⟶ ES: con vendas | EN: —
12 καὶ = and ⟶ ES: y | EN: and
13 ἡ = the (the/this/who) ⟶ ES: su rostro | EN: —
14 ὄψις = face ⟶ ES: su rostro | EN: face
15 αὐτοῦ = of him (he/she/it/self) ⟶ ES: su rostro | EN: —
16 σουδαρίῳ = in a headcloth (handkerchief) ⟶ ES: en un sudario | EN: —
17 περιεδέδετο = had bound about. (to wrap around) ⟶ ES: estaba envuelto | EN: bound
18 λέγει = Says (to speak) ⟶ ES: Les dice | EN: says
19 αὐτοῖς = to them (he/she/it/self) ⟶ ES: Les dice | EN: to them
20 ὁ = <the> (the/this/who) ⟶ ES: Jesús | EN: —
21 Ἰησοῦς· = Jesus: (Jesus/Joshua) ⟶ ES: Jesús | EN: Jesus
22 λύσατε = do unbind (to loose) ⟶ ES: Desatadle | EN: —
23 αὐτὸν = him (he/she/it/self) ⟶ ES: Desatadle | EN: him
24 καὶ = and ⟶ ES: y | EN: and
25 ἄφετε = do allow (to release) ⟶ ES: dejadle | EN: —
26 αὐτὸν = him (he/she/it/self) ⟶ ES: dejadle | EN: —
27 ὑπάγειν = to go. (to go) ⟶ ES: ir | EN: to go
```
출력:
```
43:1:1 {Nel|1} {principio|2} {era|3} {la|4} {Parola|5}, {e|6} {la|7} {Parola|8} {era|9} {presso|10} {Dio|12}, {e|13} {la|16} {Parola|17} {era|15} {Dio|14}.
1:38:27 {E avvenne|1} {al tempo|2} {del suo partorire|3}, {ed ecco|4}, c’erano {gemelli|5} {nel suo ventre|6}.
43:1:36 {E|1} {fissato lo sguardo su|2} {Gesù|4} {che passava|5}, {dice|6}: {Ecco|7} {l|8}'{Agnello|9} {di Dio|11}.
43:11:44 {Uscì|2} {il|3} {morto|4}, {legato|5} {piedi|7} {e|8} {mani|10} {con fasce|11}, {e|12} {il|13} {suo|15} {volto|14} {era avvolto|17} {in un sudario|16}. {Dice|18} {loro|19} {Gesù|21}: {Scioglietelo|22,23} {e|24} {lasciatelo|25,26} {andare|27}.
```
(실제 출력에는 ``` 를 쓰지 않는다.)
