"""영어 짝을 힌트로 붙인 다른 언어 패킷 생성.
사용: python3 -I tools/make_packets_hint.py --original O --literal-db L_xx --en-db Literal_en --refs refs.txt --out DIR --per 10 [--label ES]"""
import argparse, os, sys, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import alignlib as L
ap = argparse.ArgumentParser()
ap.add_argument("--original", required=True); ap.add_argument("--literal-db", required=True)
ap.add_argument("--en-db", required=True); ap.add_argument("--refs", required=True)
ap.add_argument("--out", required=True); ap.add_argument("--per", type=int, default=10)
ap.add_argument("--label", default="ES"); ap.add_argument("--lang", default="es")
ap.add_argument("--flags", help="[zh] edition_flags_v2.json — 제외 단어를 '(직역에 없음)'으로 표시")
a = ap.parse_args()
src = L.Source(a.original, a.lang, a.literal_db)
lits, words = src.literals(), src.words()
excluded = L.load_excluded(a.flags)
en = L.ro_connect(a.en_db)
refs = []
for line in open(a.refs, encoding="utf-8"):
    if line.startswith("#") or not line.strip(): continue
    r = L.parse_ref(line.split()[0])
    if r and r in lits and r in words: refs.append(r)
os.makedirs(a.out, exist_ok=True)
man = open(os.path.join(a.out, "manifest.jsonl"), "w", encoding="utf-8")
for p in range(0, len(refs), a.per):
    name = "p%04d.txt" % (p // a.per + 1)
    blocks = []
    for r in refs[p:p + a.per]:
        al = dict(en.execute("SELECT word_index,phrase FROM WordAlignment WHERE book_id=? AND chapter=? AND verse=?", r).fetchall())
        lines = [f"## {L.ref_str(*r)}", f"{a.label}: {lits[r]}"]
        for w in words[r]:
            tr = w["tr"].strip(); g = w["gloss"].strip()
            m = tr if tr else "-"
            if g and g.lower() != tr.lower(): m += f" ({g})"
            if w["n"] in excluded.get(r, ()):
                lines.append(f"{w['n']} {L.clean_orig(w['orig'])} = {m} ⟶ (직역에 없음: 짝 짓지 말 것)")
            else:
                lines.append(f"{w['n']} {L.clean_orig(w['orig'])} = {m} ⟶ EN: {al.get(w['n'] - 1, '—')}")
        blocks.append("\n".join(lines))
        man.write(json.dumps({"ref": L.ref_str(*r), "packet": name, "nwords": len(words[r]),
                              "wfp": L.words_fingerprint(words[r]), "tfp": L.text_fingerprint(lits[r])}, ensure_ascii=False) + "\n")
    open(os.path.join(a.out, name), "w", encoding="utf-8").write("\n\n".join(blocks) + "\n")
print(len(refs), "절")
