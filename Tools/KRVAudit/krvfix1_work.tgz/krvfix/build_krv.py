"""[krvfix1] 앱 BibleDB.sqlite의 BibleVerses.content를 대한성서공회 개역한글 정본(holybible.or.kr 수집본)으로 교체한다.
- 키(book_id, chapter, verse), uid, paragraph, 스키마는 그대로. content만 UPDATE.
- 예외 1: 시 72:19–20 — 정본 수집본은 20절을 19절 끝에 붙여 두었다("아멘 아멘. 이새의 아들 다윗의 기도가 필하다").
          19절은 "아멘 아멘"까지, 20절은 "이새의 아들 다윗의 기도가 필하다"로 나눈다.
- 예외 2: 시편 표제 — 정본 수집본에는 표제가 없다. 앱 본문이 "[표제] 본문" 형식이면 앱의 "[표제]"를 앞에 두고 본문만 정본으로 바꾼다.
사용: python3 -I build_krv.py <앱 BibleDB.sqlite(읽기)> <새 출력 경로> <krv_holybible.jsonl> <report.tsv>
"""
import json, re, sqlite3, sys
src_db, db, ref, rep = sys.argv[1:5]
import os, shutil
if os.path.exists(db) or os.path.realpath(src_db) == os.path.realpath(db):
    sys.exit("출력 파일이 이미 있거나 입력과 같습니다")
shutil.copyfile(src_db, db)
H = {}
for line in open(ref, encoding="utf-8"):
    r = json.loads(line)
    H[(r["book"], r["chapter"], r["verse"])] = r["text"]
con = sqlite3.connect(db)
rows = con.execute("SELECT book_id, chapter, verse, content FROM BibleVerses").fetchall()
keys = {(b, c, v) for b, c, v, _ in rows}
if set(H) - keys or keys - set(H) != {(19, 72, 20)}:
    sys.exit(f"키 불일치: 참조에만 {sorted(set(H)-keys)[:5]} / 앱에만 {sorted(keys-set(H))[:5]}")
p = H[(19, 72, 19)]
sep = "아멘 아멘. "
if not (p.count(sep) == 1 and p.endswith("이새의 아들 다윗의 기도가 필하다")):
    sys.exit(f"시 72:19 형식이 다름: {p}")
v19, v20 = p.split(sep)
new = dict(H)
new[(19, 72, 19)] = v19 + "아멘 아멘"
new[(19, 72, 20)] = v20
title_re = re.compile(r"^(\[[^\]]+\])\s*")
log = []
for b, c, v, old in rows:
    t = new[(b, c, v)]
    m = title_re.match(old)
    if b == 19 and m and not t.startswith("["):
        t = re.sub(r"\s+", " ", m.group(1)) + " " + t
        log.append(("title_kept", b, c, v))
    if not (t and t == t.strip() and "\n" not in t and "\r" not in t and "  " not in t):
        sys.exit(f"본문 형식 오류: {(b, c, v, t)}")
    new[(b, c, v)] = t
changed = 0
with con:
    for b, c, v, old in rows:
        t = new[(b, c, v)]
        if t != old:
            con.execute("UPDATE BibleVerses SET content=? WHERE book_id=? AND chapter=? AND verse=?", (t, b, c, v))
            changed += 1
ic = con.execute("PRAGMA integrity_check").fetchone()[0]
n = con.execute("SELECT count(*) FROM BibleVerses").fetchone()[0]
con.close()
with open(rep, "w", encoding="utf-8") as f:
    for x in log:
        f.write("\t".join(map(str, x)) + "\n")
print(f"rows {n} changed {changed} titles_kept {len(log)} integrity {ic}")
