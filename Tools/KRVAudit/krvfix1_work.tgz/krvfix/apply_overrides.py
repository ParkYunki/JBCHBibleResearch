"""[krvfix1-o] 대한성서공회 성경플랫폼(bible.bskorea.or.kr/bible/KRV) 본문으로 지정 절을 덮어쓴다(사용자 결정).
python3 -I apply_overrides.py IN.sqlite OUT.sqlite overrides.json"""
import json,os,shutil,sqlite3,sys
src,dst,ov=sys.argv[1:4]
if os.path.exists(dst): sys.exit('출력 파일이 이미 있음')
shutil.copyfile(src,dst)
o=json.load(open(ov,encoding='utf-8'))
con=sqlite3.connect(dst)
with con:
  for k,t in o.items():
    b,c,v=map(int,k.split(':'))
    old=con.execute('select content from BibleVerses where book_id=? and chapter=? and verse=?',(b,c,v)).fetchone()
    if old is None or not t.strip() or '  ' in t: sys.exit(f'오류 {k}')
    con.execute('update BibleVerses set content=? where book_id=? and chapter=? and verse=?',(t,b,c,v))
    print(k,'|',old[0],'\n   →',t)
print(con.execute('pragma integrity_check').fetchone()[0], con.execute('select count(*) from BibleVerses').fetchone()[0])
