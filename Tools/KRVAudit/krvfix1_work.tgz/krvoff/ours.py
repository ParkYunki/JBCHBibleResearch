import sqlite3,hashlib,json,re,sys
B=["GEN","EXO","LEV","NUM","DEU","JOS","JDG","RUT","1SA","2SA","1KI","2KI","1CH","2CH","EZR","NEH","EST","JOB","PSA","PRO","ECC","SNG","ISA","JER","LAM","EZK","DAN","HOS","JOL","AMO","OBA","JON","MIC","NAM","HAB","ZEP","HAG","ZEC","MAL","MAT","MRK","LUK","JHN","ACT","ROM","1CO","2CO","GAL","EPH","PHP","COL","1TH","2TH","1TI","2TI","TIT","PHM","HEB","JAS","1PE","2PE","1JN","2JN","3JN","JUD","REV"]
db=sys.argv[1]
ch={}
for b,c,v,t in sqlite3.connect(db).execute('select book_id,chapter,verse,content from BibleVerses order by 1,2,3'):
  k=f'{B[b-1]}.{c}'; d=ch.setdefault(k,{'v':[],'title':''})
  m=re.match(r'^\[([^\]]+)\]\s*',t) if b==19 and v==1 else None
  if m: d['title']=m.group(1); t=t[m.end():]
  d['v'].append(t)
out={}
for k,d in ch.items():
  s='\n'.join(f'{i}\t'+re.sub(r'\s+','',t) for i,t in enumerate(d['v'],1))
  out[k]=[len(d['v']),hashlib.sha256(s.encode()).hexdigest()[:16],d['title']]
json.dump(out,open(sys.argv[2],'w'),ensure_ascii=False)
print(len(out))
