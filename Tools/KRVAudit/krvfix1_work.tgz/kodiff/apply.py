import json,sqlite3,re,shutil,sys,os
q=json.load(open('q2.json'))
ag={}
for f in ['out_word_1.jsonl','out_word_2.jsonl']:
  for l in open(f,encoding='utf-8'):
    l=l.strip()
    if l: r=json.loads(l); ag[r['uid']]=r
need={int(u) for u,x in q.items() if any(e['kind']=='word' for e in x['edits'])}
print('agent uids',len(ag),'need',len(need),'missing',sorted(need-set(ag))[:5],'extra',sorted(set(ag)-need)[:5])
O={(b,c,v):t for b,c,v,t in sqlite3.connect('/home/claude/krv/BibleDB.sqlite').execute('select book_id,chapter,verse,content from BibleVerses')}
N={(b,c,v):t for b,c,v,t in sqlite3.connect('/home/claude/krvfix/BibleDB_new2.sqlite').execute('select book_id,chapter,verse,content from BibleVerses')}
QRE=re.compile(r"‘([^‘’]+)’|“([^“”]+)”|「([^「」]+)」|'([^'\n]+)'|\"([^\"\n]+)\"")
def stale(k,d):
  out=[]
  for m in QRE.finditer(d):
    s=next(g for g in m.groups() if g is not None)
    if s not in N[k] and s in O[k]: out.append(s)
  return out
dst='OriginalText_q.sqlite'
if os.path.exists(dst): sys.exit('exists')
shutil.copyfile('/home/claude/integ/align/src/OriginalText.sqlite',dst)
con=sqlite3.connect(dst)
cnt={'mech':0,'keep':0,'edit':0}; probs=[]
with con:
  for u,x in q.items():
    u=int(u); k=tuple(x['ref'])
    cur=con.execute('select difference from LiteralTranslation where uid=?',(u,)).fetchone()[0]
    assert cur==x['diff']
    if u in need:
      r=ag.get(u)
      if not r: probs.append((k,'no agent')); continue
      d=r['explanation']; cnt[r['action']]+=1
    else:
      d=x['diff']
      for e in sorted(x['edits'],key=lambda e:-e['pos']):
        assert d[e['pos']:e['pos']+len(e['old'])]==e['old']
        d=d[:e['pos']]+e['new']+d[e['pos']+len(e['old']):]
      cnt['mech']+=1
    st=stale(k,d)
    if st or not d.strip(): probs.append((k,st)); continue
    con.execute('update LiteralTranslation set difference=? where uid=?',(d,u))
print(cnt,'problems',len(probs),probs[:10])
print(con.execute('pragma integrity_check').fetchone())
con.close()
