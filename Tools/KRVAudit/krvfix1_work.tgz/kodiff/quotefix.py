"""[krvfix1-q] OriginalText.LiteralTranslation.difference 안의 개역한글 인용(‘…’ “…” 「…」)을 새 개역한글 본문 표기에 맞춘다.
인용 s가 새 본문에 있으면 그대로. 옛 본문에만 있으면 옛→새 글자 정렬로 대응 구간을 찾아 바꾼다.
분류: same(그대로) / ws(띄어쓰기·문장부호만) / ortho(표기만) / word(낱말 다름) / gone(대응 구간 없음·불확실)
python3 -I quotefix.py OLD_KRV NEW_KRV ORIGINALTEXT OUT.json
"""
import difflib, json, re, sqlite3, sys
oldp, newp, otp, outp = sys.argv[1:5]
ld = lambda p: {(b, c, v): t for b, c, v, t in sqlite3.connect(f"file:{p}?mode=ro", uri=True).execute(
    "SELECT book_id,chapter,verse,content FROM BibleVerses")}
O, N = ld(oldp), ld(newp)
P = r"[\s,.;:!?'\"“”‘’()\[\]·…「」\-]"
def core(t): return re.sub(P, "", t)
ORTHO = [("세째", "셋째"), ("네째", "넷째"), ("찌", "지"), ("찐", "진"), ("찍", "직"), ("쌔", "새"), ("숫군", "수꾼"),
         ("군", "꾼"), ("륙", "육"), ("왔", "웠"), ("와", "워"), ("년", "연"), ("의", "희"), ("웻", "웹"), ("깎", "깍"), ("래", "랫"),
         ("세례", "침례"), ("지기", "직이")]
def onorm(t):
    t = core(t)
    for a, b in ORTHO: t = t.replace(a, b)
    return t
QRE = re.compile(r"‘([^‘’]+)’|“([^“”]+)”|「([^「」]+)」|'([^'\n]+)'|\"([^\"\n]+)\"")
def mapspan(old, new, i, j):
    sm = difflib.SequenceMatcher(None, old, new, autojunk=False)
    ns = ne = None
    for tag, a1, a2, b1, b2 in sm.get_opcodes():
        if ns is None and a1 <= i < a2 or (ns is None and a1 == a2 == i):
            ns = b1 + (i - a1) if tag == "equal" else b1
        if a1 < j <= a2:
            ne = b1 + (j - a1) if tag == "equal" else b2
    return (ns, ne)
ot = sqlite3.connect(f"file:{otp}?mode=ro", uri=True)
res = {}
stats = {}
for uid, b, c, v, diff in ot.execute("SELECT uid,book_id,chapter,verse,difference FROM LiteralTranslation"):
    k = (b, c, v)
    if not diff or k not in O or O[k] == N[k]:
        continue
    old, new = O[k], N[k]
    edits = []
    for m in QRE.finditer(diff):
        s = next(g for g in m.groups() if g is not None)
        if s in new or s not in old:
            continue
        cands = set()
        for mm in re.finditer(re.escape(s), old):
            ns, ne = mapspan(old, new, mm.start(), mm.end())
            if ns is None or ne is None or ne <= ns:
                cands.add(None)
            else:
                cands.add(new[ns:ne].strip())
        if len(cands) != 1 or None in cands or not next(iter(cands)):
            kind, t = "gone", None
        else:
            t = next(iter(cands))
            kind = "ws" if core(t) == core(s) else ("ortho" if onorm(t) == onorm(s) else "word")
        stats[kind] = stats.get(kind, 0) + 1
        gs = m.start(next(i for i, g in enumerate(m.groups(), 1) if g is not None))
        edits.append({"pos": gs, "old": s, "new": t, "kind": kind})
    if edits:
        res[uid] = {"ref": k, "diff": diff, "old_krv": old, "new_krv": new, "edits": edits}
json.dump(res, open(outp, "w"), ensure_ascii=False, indent=0)
print("verses", len(res), "quotes", stats)
