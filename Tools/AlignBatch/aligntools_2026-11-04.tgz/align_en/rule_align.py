"""영어 직역(LSV) ↔ 원어 단어 규칙 기반 짝짓기 (AI 없음).
각 원어 단어의 translation_en을 직역 문장의 어절과 문자열로 맞춘다.
사용: python3 -I rule_align.py ORIGINAL.sqlite LITERAL_EN.sqlite OUT.jsonl
출력: 절마다 {"ref":"b:c:v","n":단어수,"pairs":[[word_index, phrase, start], ...]}
"""
import sqlite3, sys, re, json, collections

STOP = {"the", "a", "an", "of", "to", "and", "in", "on", "at", "for", "with", "by", "from", "is", "be", "was", "were",
        "are", "that", "this", "which", "who", "it", "he", "she", "they", "his", "her", "him", "them", "their",
        "as", "or", "but", "not", "will", "shall", "have", "has", "had", "do", "did", "o", "my", "your", "you", "i", "me", "we", "us", "our"}
PUNCT = "\"'“”‘’.,;:!?()[]{}—–-…"


IRR = {"said": "say", "says": "say", "saying": "say", "went": "go", "goes": "go", "gone": "go", "came": "come", "comes": "come",
       "gave": "give", "given": "give", "gives": "give", "took": "take", "taken": "take", "takes": "take", "saw": "see", "seen": "see",
       "sees": "see", "made": "make", "makes": "make", "was": "be", "were": "be", "is": "be", "are": "be", "been": "be", "am": "be",
       "has": "have", "had": "have", "did": "do", "does": "do", "knew": "know", "known": "know", "knows": "know", "begat": "beget",
       "begot": "beget", "begotten": "beget", "spoke": "speak", "spoken": "speak", "speaks": "speak", "brought": "bring", "sent": "send",
       "found": "find", "heard": "hear", "kept": "keep", "built": "build", "dwelt": "dwell", "stood": "stand", "sat": "sit",
       "men": "man", "sons": "son", "children": "child", "daughters": "daughter", "people": "people", "days": "day", "years": "year"}


def lemma(t):
    if t in IRR:
        return IRR[t]
    for suf in ("ing", "ed", "es", "s"):
        if len(t) > len(suf) + 2 and t.endswith(suf):
            return t[: -len(suf)]
    return t


def core(tok):
    t = tok.strip(PUNCT)
    return t.lower()


def tokens(text):
    out = []
    for m in re.finditer(r"\S+", text):
        raw = m.group(0)
        s, e = m.start(), m.end()
        # 앞뒤 문장부호·괄호를 구간 밖으로
        while s < e and text[s] in PUNCT:
            s += 1
        while e > s and text[e - 1] in PUNCT:
            e -= 1
        if s >= e:
            continue
        w = text[s:e].lower()
        if "[" in w or "]" in w:
            continue
        out.append((lemma(w), s, e))
    return out


def gloss_tokens(g):
    g = g.replace("<obj.>", " ").replace("/", " ")
    g = re.sub(r"\[([^\]]*)\]", r"\1", g)
    return [lemma(core(t)) for t in g.split() if core(t)]


def align(words, text):
    toks = tokens(text)
    n = len(toks)
    used = [False] * n
    pairs = []
    W = len(words)
    for wi, (gl,) in enumerate(words):
        gt = gloss_tokens(gl)
        if not gt:
            continue
        expect = (wi + 0.5) / W * n
        best = None
        # 1) 연속 전체 일치
        L = len(gt)
        for s in range(0, n - L + 1):
            if all(toks[s + k][0] == gt[k] for k in range(L)) and not any(used[s:s + L]):
                d = abs(s - expect)
                if best is None or d < best[0]:
                    best = (d, s, s + L)
        # 2) 내용어 하나(가장 긴 것)만 일치
        if best is None:
            content = sorted([t for t in gt if t not in STOP and t not in ("be", "have", "do", "say")], key=len, reverse=True) or [t for t in gt if t in ("say",)]
            for c in content:
                cands = [s for s in range(n) if toks[s][0] == c and not used[s]]
                if cands:
                    s = min(cands, key=lambda x: abs(x - expect))
                    best = (abs(s - expect), s, s + 1)
                    break
        if best is None:
            continue
        _, s, e = best
        for k in range(s, e):
            used[k] = True
        start, end = toks[s][1], toks[e - 1][2]
        if any(ch in text[start:end] for ch in "[]()\"“”"):
            # 구간 안에 괄호·따옴표가 끼면 마지막 낱말만 쓴다(예: "the] Father" → "Father").
            start = toks[e - 1][1]
        pairs.append([wi, text[start:end], len(text[:start])])
    return pairs


def main():
    o = sqlite3.connect(f"file:{sys.argv[1]}?immutable=1", uri=True)
    e = sqlite3.connect(f"file:{sys.argv[2]}?immutable=1", uri=True)
    lit = {(b, c, v): t for b, c, v, t in e.execute("select book_id,chapter,verse,text from LiteralText")}
    words = collections.defaultdict(list)
    for b, c, v, g in o.execute("select book_id,chapter,verse,translation_en from original_words order by book_id,chapter,verse,word_order,rowid"):
        words[(b, c, v)].append((g,))
    tw = tm = 0
    with open(sys.argv[3], "w", encoding="utf-8") as f:
        for k, ws in words.items():
            t = lit.get(k)
            if t is None:
                continue
            pairs = align(ws, t)
            tw += len(ws); tm += len(pairs)
            f.write(json.dumps({"ref": "%d:%d:%d" % k, "n": len(ws), "pairs": pairs}, ensure_ascii=False) + "\n")
    print(f"단어 {tw} / 짝 {tm} ({tm / tw:.1%})")


if __name__ == "__main__":
    main()
